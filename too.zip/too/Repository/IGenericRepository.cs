﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Repository
{
    public interface IGenericRepository<T> //: IDisposable
    {

        IEnumerable<T> ExecuteQuery(string spQuery, object[] parameters);
        T ExecuteQuerySingle(string spQuery, object[] parameters);
        int ExecuteCommand(string spQuery, object[] parameters);
        T ExecuteCommandWithList(string spQuery, object[] parameters);
    }
}