﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Repository
{
    public class SessionManager
    {
        public static string AppNo
        {
            get
            {
                if (HttpContext.Current.Session["AppNo"] != null)
                {
                    return (HttpContext.Current.Session["AppNo"]).ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["AppNo"] = value;
            }
        }
        public static Int32 StepNo
        {
            get
            {
                if (HttpContext.Current.Session["StepNo"] != null)
                {
                    return (Int32)(HttpContext.Current.Session["StepNo"]);
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["StepNo"] = value;
            }
        }
        public static string UserType
        {
            get
            {
                if (HttpContext.Current.Session["UserType"] != null)
                {
                    return (HttpContext.Current.Session["UserType"]).ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["UserType"] = value;
            }
        }

        public static string DisplayName
        {
            get
            {
                if (HttpContext.Current.Session["DisplayName"] != null)
                {
                    return (HttpContext.Current.Session["DisplayName"]).ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["DisplayName"] = value;
            }
        }

        public static string EmailID
        {
            get
            {
                if (HttpContext.Current.Session["EmailID"] != null)
                {
                    return (HttpContext.Current.Session["EmailID"]).ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["EmailID"] = value;
            }
        }

        public static string Username
        {
            get
            {
                if (HttpContext.Current.Session["Username"] != null)
                {
                    return (HttpContext.Current.Session["Username"].ToString());
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["Username"] = value;
            }
        }

        public static string MobileNo
        {
            get
            {
                if (HttpContext.Current.Session["MobileNo"] != null)
                {
                    return (string)(HttpContext.Current.Session["MobileNo"]);
                }
                else
                {
                    return "";
                }
            }
            set
            {
                HttpContext.Current.Session["MobileNo"] = value;
            }

        }

        public static string ApplicantName
        {
            get
            {
                if (HttpContext.Current.Session["ApplicantName"] != null)
                {
                    return (HttpContext.Current.Session["ApplicantName"]).ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["ApplicantName"] = value;
            }
        }

        public static Int64 UserId
        {
            get
            {
                if (HttpContext.Current.Session["UserId"] != null)
                {
                    return (Int64)(HttpContext.Current.Session["UserId"]);
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["UserId"] = value;
            }
        }



        public static Int64 RegistrationID
        {
            get
            {
                if (HttpContext.Current.Session["RegistrationID"] != null)
                {
                    return Convert.ToInt64(HttpContext.Current.Session["RegistrationID"]);
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["RegistrationID"] = value;
            }
        }
       

        public static Int16 FormTypeID
        {
            get
            {
                if (HttpContext.Current.Session["FormTypeID"] != null)
                {
                    return Convert.ToInt16(HttpContext.Current.Session["FormTypeID"]);
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["FormTypeID"] = value;
            }
        }

        public static Int16 UserCategoryID
        {
            get
            {
                if (HttpContext.Current.Session["UserCategoryID"] != null)
                {
                    return Convert.ToInt16(HttpContext.Current.Session["UserCategoryID"]);
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["UserCategoryID"] = value;
            }
        }

        public static Int16 UserTypeID
        {
            get
            {
                if (HttpContext.Current.Session["UserTypeID"] != null)
                {
                    return Convert.ToInt16(HttpContext.Current.Session["UserTypeID"]);
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["UserTypeID"] = value;
            }
        }

        

     

        public static string UserName
        {
            get
            {
                if (HttpContext.Current.Session["UserName"] != null)
                {
                    return (HttpContext.Current.Session["UserName"]).ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["UserName"] = value;
            }
        }

    }
}