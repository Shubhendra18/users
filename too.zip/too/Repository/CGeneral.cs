﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Reflection;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using Newtonsoft.Json;

namespace GroundWaterDept.Repository
{
    public class CGeneral
    {
        public static string getIPAddress()
        {

            String ip = "";
            try
            {
                ip = Convert.ToString(HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"]);
                if (!string.IsNullOrEmpty(ip))
                {
                    string[] ipRange = ip.Split(',');
                    int le = ipRange.Length - 1;
                    string trueIP = ipRange[le];
                }
                else
                {
                    ip = Convert.ToString(HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]);
                }
            }
            catch
            {
                ip = Convert.ToString(HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]);
            }
            return ip;
        }
        public static XmlDocument ConvertJSONToXML(string hdnValue)
        {
            XmlDocument xml = new XmlDocument();
            try
            {
                xml = JsonConvert.DeserializeXmlNode("{\"column\":" + hdnValue + "}", "Table");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return xml;
        }
        public static String SMSSend(String Message, String Recipient)
        {
            string MessageResponse = string.Empty;
            try
            {
                WebClient Client = new WebClient();

                string baseurl = "";
                Stream data = Client.OpenRead(baseurl);
                StreamReader reader = new StreamReader(data);
                MessageResponse = reader.ReadToEnd();
                if (MessageResponse.Substring(0, 4) == "1701")
                {
                    MessageResponse = "SUCCESS";
                }

                data.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
                return MessageResponse + " " + ex.Message;
            }
            return MessageResponse;
        }
        public static bool SendEmail(String mailto, String Subject, String mailBody)
        {

            bool isSend = false;
            string mailSubject = Subject;
            string mailfrom = ConfigurationManager.AppSettings["FromMail"].ToString();
            string host = ConfigurationManager.AppSettings["ServerIp"].ToString();
            string uid = ConfigurationManager.AppSettings["UserID"].ToString();
            string pwd = ConfigurationManager.AppSettings["Password"].ToString();
            string mailMessage = mailBody;


            SmtpClient MyMail = new SmtpClient();
            MailMessage MyMsg = new MailMessage();
            MyMail.Host = host;
            MyMsg.Priority = MailPriority.High;
            MyMsg.To.Add(new MailAddress(mailto));
            MyMsg.Subject = Subject;
            MyMsg.SubjectEncoding = Encoding.UTF8;
            MyMsg.IsBodyHtml = true;
            MyMsg.From = new MailAddress(mailfrom);
            MyMsg.BodyEncoding = Encoding.UTF8;
            MyMsg.Body = mailBody;
            MyMail.UseDefaultCredentials = false;
            NetworkCredential MyCredentials = new NetworkCredential(uid, pwd);
            MyMail.Credentials = MyCredentials;
            MyMail.DeliveryMethod = SmtpDeliveryMethod.Network;
            try
            {
                MyMail.Send(MyMsg);
                isSend = true;
            }
            catch
            {
                isSend = false;
            }
            finally
            {
                MyMail = null;
                MyMsg = null;
            }

            return isSend;
        }
        public static string ToXml<T>(List<T> items)
        {
            DataSet dataset = new DataSet();
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            dataset.Tables.Add(dataTable);
            dataset.AcceptChanges();
            return dataset.GetXml().ToString();

        }
        public static string HashValue(string value)
        {
            return (Convert.ToInt64(value)).ToString("X");
        }
        public static string ReverseHashToValue(string hexValue)
        {
            return (Int64.Parse(hexValue, System.Globalization.NumberStyles.HexNumber)).ToString();
        }
        public static string RandomString(int length)
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        public static string ConvertNumbertoWords(int number)
        {
            if (number == 0)
                return "Zero";
            if (number < 0)
                return "minus " + ConvertNumbertoWords(Math.Abs(number));
            string words = "";

            if ((number / 1000000000) > 0)
            {
                words += ConvertNumbertoWords(number / 1000000000) + " Billion ";
                number %= 1000000000;
            }

            if ((number / 10000000) > 0)
            {
                words += ConvertNumbertoWords(number / 10000000) + " Crore ";
                number %= 10000000;
            }

            if ((number / 1000000) > 0)
            {
                words += ConvertNumbertoWords(number / 1000000) + " Million ";
                number %= 1000000;
            }
            if ((number / 1000) > 0)
            {
                words += ConvertNumbertoWords(number / 1000) + " Thousand ";
                number %= 1000;
            }
            if ((number / 100) > 0)
            {
                words += ConvertNumbertoWords(number / 100) + " Hundred ";
                number %= 100;
            }
            if (number > 0)
            {
                if (words != "")
                    words += "and ";
                var unitsMap = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
                var tensMap = new[] { "Zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

                if (number < 20)
                    words += unitsMap[number];
                else
                {
                    words += tensMap[number / 10];
                    if ((number % 10) > 0)
                        words += " " + unitsMap[number % 10];
                }
            }
            return words;
        }
        public static string GetRendomNo(int lenth)
        {
            string allowedChars = "";
            allowedChars += "1,2,3,4,5,6,7,8,9,0";
            char[] sep = { ',' };
            string[] arr = allowedChars.Split(sep);
            string temp = "";
            string tempPass = "";
            Random rand = new Random();
            for (int i = 0; i < lenth; i++)
            {
                temp = arr[rand.Next(0, arr.Length)];
                tempPass += temp;
            }
            return tempPass;
        }
        public static string GetRendomPassword(int lenth)
        {
            string allowedChars = "";
            allowedChars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
            //char[] sep = { ',' };
            //string[] arr = allowedChars;

            string tempPass = "";
            var stringChars = new char[8];
            Random rand = new Random();
            for (int i = 0; i < lenth; i++)
            {
                stringChars[i] = allowedChars[rand.Next(0, allowedChars.Length)];
                tempPass += stringChars[i];
            }
            return tempPass;
        }
        public static DataTable ListToDatatble<T>(IEnumerable<T> Linqlist)
        {
            DataTable dt = new DataTable();

            PropertyInfo[] columns = null;

            if (Linqlist == null) return dt;

            foreach (T Record in Linqlist)
            {
                if (columns == null)
                {
                    columns = ((Type)Record.GetType()).GetProperties();
                    foreach (PropertyInfo GetProperty in columns)
                    {
                        Type IcolType = GetProperty.PropertyType;

                        if ((IcolType.IsGenericType) && (IcolType.GetGenericTypeDefinition() == typeof(Nullable<>)))
                        {
                            IcolType = IcolType.GetGenericArguments()[0];
                        }

                        dt.Columns.Add(new DataColumn(GetProperty.Name, IcolType));
                    }
                }

                DataRow dr = dt.NewRow();

                foreach (PropertyInfo p in columns)
                {
                    dr[p.Name] = p.GetValue(Record, null) == null ? DBNull.Value : p.GetValue
                    (Record, null);
                }

                dt.Rows.Add(dr);
            }
            return dt;
        }
    }
    public static class Extensions
    {
        public static List<T> ToList<T>(this DataTable table) where T : new()
        {
            IList<PropertyInfo> properties = typeof(T).GetProperties().ToList();
            List<T> result = new List<T>();

            foreach (var row in table.Rows)
            {
                var item = CreateItemFromRow<T>((DataRow)row, properties);
                result.Add(item);
            }

            return result;
        }
        private static T CreateItemFromRow<T>(DataRow row, IList<PropertyInfo> properties) where T : new()
        {
            T item = new T();
            foreach (var property in properties)
            {
                if (property.PropertyType == typeof(System.DayOfWeek))
                {
                    DayOfWeek day = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), row[property.Name].ToString());
                    property.SetValue(item, day, null);
                }
                else
                {
                    try
                    {
                        if (row[property.Name] == DBNull.Value)
                            property.SetValue(item, null, null);
                        else
                            property.SetValue(item, row[property.Name], null);
                    }
                    catch
                    {

                    }
                }
            }
            return item;
        }
    }
}