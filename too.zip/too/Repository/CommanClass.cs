﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace GroundWaterDept.Repository
{
    public class CommanClass
    {
        public string ValidatePdfFileWithCusomSize(HttpPostedFileBase image, int ImageSize)
        {
            string massage;
            String fn = Path.GetFileNameWithoutExtension(image.FileName);
            String ext = Path.GetExtension(image.FileName);
            char[] SpecialChars = "!@#$%^&*()+=~`\\|/?><,\"".ToCharArray();
            int indexOf = fn.IndexOfAny(SpecialChars);
            String fileName = fn;
            int count = fileName.Split('.').Length - 1;
            if (count > 1)
            {
                massage = "Double extension not allowed in file name";

            }
            else
            {
                if (indexOf != -1)
                {
                    massage = "Special character not allowed in file name";

                }
                else
                {
                    string mimetype = image.ContentType;
                    if (ext == ".pdf" && mimetype == "application/pdf")
                    {
                        fn = "";

                        string fFullName = image.FileName;
                        int len = fFullName.Length;
                        string ext1 = Path.GetExtension(fFullName);
                        string str = fFullName.Substring(fFullName.LastIndexOf("\\") + 1);
                        len = str.Length;
                        string fileN = str.Substring(0, len - ext1.Length);

                        Regex FilenameRegex = null;
                        FilenameRegex = new Regex("(.*?)\\.(pdf|PDF)$", RegexOptions.IgnoreCase);
                        int index = fileN.IndexOf(".");

                        if (!FilenameRegex.IsMatch(fFullName) || index != -1)
                        {
                            massage = "Please upload .pdf file only";

                        }
                        else
                        {
                            string Photoname = Path.GetFileNameWithoutExtension(image.FileName);
                            string fileSize = image.ContentLength.ToString();
                            String ImageFileNameMBA = image.FileName;

                            Byte[] stu_imageMBA = new Byte[image.ContentLength];

                            Stream fs = image.InputStream;
                            fs.Read(stu_imageMBA, 0, Convert.ToInt32(fileSize));

                            fs.Seek(0, SeekOrigin.Begin);
                            StreamReader sr = new StreamReader(fs, true);

                            string firstLine = sr.ReadLine().ToString();

                            //string firstLine = "JFIF";

                            if ((firstLine.IndexOf("%PDF") > -1))
                            {

                                if (image.ContentLength <= 1024 * ImageSize)
                                {
                                    massage = "Valid";

                                }

                                else
                                {
                                    massage = "File size can not exceed " + ImageSize + " KB ";
                                }
                            }
                            else
                            {
                                massage = "Please upload .pdf file only";
                            }
                        }
                    }
                    else
                    {
                        massage = "Please upload .pdf file only";
                    }
                }
            }
            return massage;
        }
        public string ValidateImageExtWithSize(HttpPostedFileBase image, int ImageSize)
        {
            string massage;
            String fn = Path.GetFileNameWithoutExtension(image.FileName);
            String ext = Path.GetExtension(image.FileName);
            char[] SpecialChars = "!@#$%^&*()+=~`\\|/?><,\"".ToCharArray();
            int indexOf = fn.IndexOfAny(SpecialChars);
            String fileName = fn;
            int count = fileName.Split('.').Length - 1;
            if (count > 1)
            {
                massage = "Double extension not allowed in file name";

            }
            else
            {
                if (indexOf != -1)
                {
                    massage = "Special character not allowed in file name";

                }
                else
                {
                    string mimetype = image.ContentType;
                    if ((ext == ".jpg" || ext == ".jpeg") && (mimetype == "image/jpeg" || mimetype == "image/jpg"))
                    {
                        fn = "";

                        string fFullName = image.FileName;
                        int len = fFullName.Length;
                        string ext1 = Path.GetExtension(fFullName);
                        string str = fFullName.Substring(fFullName.LastIndexOf("\\") + 1);
                        len = str.Length;
                        string fileN = str.Substring(0, len - ext1.Length);

                        Regex FilenameRegex = null;
                        FilenameRegex = new Regex("(.*?)\\.(jpeg|jpg|JPEG|JPG)$", RegexOptions.IgnoreCase);
                        int index = fileN.IndexOf(".");

                        if (!FilenameRegex.IsMatch(fFullName) || index != -1)
                        {
                            massage = "Please upload .jpg or .jpeg file only";

                        }
                        else
                        {
                            string Photoname = Path.GetFileNameWithoutExtension(image.FileName);
                            string fileSize = image.ContentLength.ToString();
                            String ImageFileNameMBA = image.FileName;

                            Byte[] stu_imageMBA = new Byte[image.ContentLength];

                            Stream fs = image.InputStream;
                            fs.Read(stu_imageMBA, 0, Convert.ToInt32(fileSize));

                            fs.Seek(0, SeekOrigin.Begin);
                            StreamReader sr = new StreamReader(fs, true);

                            string firstLine = sr.ReadLine().ToString();

                            //string firstLine = "JFIF";

                            if ((firstLine.IndexOf("JFIF") > -1) || (firstLine.IndexOf("Exif") > -1))
                            {

                                if (image.ContentLength <= 1024 * ImageSize)
                                {
                                    massage = "Valid";

                                }

                                else
                                {
                                    massage = "File size can not exceed " + ImageSize + " KB ";
                                }
                            }
                            else
                            {
                                massage = "Please upload .jpg or .jpeg file only";
                            }
                        }
                    }
                    else
                    {
                        massage = "Please upload .jpg or .jpeg file only";
                    }
                }
            }
            return massage;
        }
    }
}