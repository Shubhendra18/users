﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.Entity;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Configuration;
using GroundWaterDept.Areas.DrillingAgency.Models;
using GroundWaterDept.Areas.DrillingAgency.DataLayer;

namespace GroundWaterDept.Repository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private DrillingDBLayer db;

        /// <summary>
        /// Get Data From Database
        /// <para>Use it when to retive data through a stored procedure</para>
        /// </summary>
        public IEnumerable<T> ExecuteQuery(string spQuery, object[] parameters)
        {


            using (db = new DrillingDBLayer())
            {
                return db.Database.SqlQuery<T>(spQuery, parameters).ToList();
            }


        }

        /// <summary>
        /// Get Single Data From Database
        /// <para>Use it when to retive single data through a stored procedure</para>
        /// </summary>

        public T ExecuteQuerySingle(string spQuery, object[] parameters)
        {


            using (db = new DrillingDBLayer())
            {
                return db.Database.SqlQuery<T>(spQuery, parameters).FirstOrDefault();
            }
        }

        /// <summary>
        /// Insert/Update/Delete Data To Database
        /// <para>Use it when to Insert/Update/Delete data through a stored procedure</para>
        /// </summary>
        public int ExecuteCommand(string spQuery, object[] parameters)
        {
            int result = 0;
            try
            {
                using (db = new DrillingDBLayer())
                {
                    result = db.Database.SqlQuery<int>(spQuery, parameters).FirstOrDefault();
                }
            }
            catch { }
            return result;
        }

        /// <summary>
        /// Insert/Update/Delete Data To Database having List in return
        /// <para>Use it when to Insert/Update/Delete data through a stored procedure</para>
        /// </summary>
        public T ExecuteCommandWithList(string spQuery, object[] parameters)
        {
            using (db = new DrillingDBLayer())
            {
                return db.Database.SqlQuery<T>(spQuery, parameters).FirstOrDefault();
            }
        }




        public int Insert(object[] parameters, string spName)
        {
            GenericRepository<T> registerRepository = new GenericRepository<T>();
            string param = "";
            for (int i = 0; i < parameters.Length; i++)
            {
                param = param + "{" + i.ToString() + "},";
            }

            int index = param.LastIndexOf(',');

            string spQuery = "[" + spName + "] " + param.Substring(0, index);
            return registerRepository.ExecuteCommand(spQuery, parameters);
        }

        public T InsertWithList(object[] parameters, string spName)
        {
            GenericRepository<T> registerRepository = new GenericRepository<T>();
            string param = "";
            for (int i = 0; i < parameters.Length; i++)
            {
                param = param + "{" + i.ToString() + "},";
            }

            int index = param.LastIndexOf(',');

            string spQuery = "[" + spName + "] " + param.Substring(0, index);
            return registerRepository.ExecuteCommandWithList(spQuery, parameters);
        }

        public T GetbyID(object[] parameters, string spName)
        {
            GenericRepository<T> registerRepository = new GenericRepository<T>();
            //string spQuery = "[Get_CustomerbyID] {0}";
            string param = "";
            for (int i = 0; i < parameters.Length; i++)
            {
                param = param + "{" + i.ToString() + "},";
            }
            int index = param.LastIndexOf(',');
            string spQuery = "[" + spName + "] " + param.Substring(0, index);
            return registerRepository.ExecuteQuerySingle(spQuery, parameters);
        }

        public IEnumerable<T> GetAllData(object[] parameters, string spName)
        {
            GenericRepository<T> registerRepository = new GenericRepository<T>();
            //string spQuery = "[Get_CustomerbyID] {0}";
            string param = "";
            for (int i = 0; i < parameters.Length; i++)
            {
                param = param + "{" + i.ToString() + "},";
            }
            int index = param.LastIndexOf(',');
            string spQuery = string.Empty;
            if (index > 0)
                spQuery = "[" + spName + "] " + param.Substring(0, index);
            else
                spQuery = "[" + spName + "] ";

            return registerRepository.ExecuteQuery(spQuery, parameters);
        }


        public T StoredProcedureMultipleResult(string spQuery, object[] parameters)
        {
            using (DrillingDBLayer dbContext = new DrillingDBLayer())
            {
                string param = "";
                for (int i = 0; i < parameters.Length; i++)
                {
                    param = param + "{" + i.ToString() + "},";
                }

                int index = param.LastIndexOf(',');

                string sql = "[" + spQuery + "] " + param.Substring(0, index);

                T t = (T)dbContext.Database.SqlQuery<T>(sql, parameters).AsQueryable<T>();

            }
            var value = typeof(T);
            return (T)Convert.ChangeType(value, typeof(T));
        }

        public DataSet MultipleResult(string spQuery, object[] parameters)
        {
            using (DrillingDBLayer dbContext = new DrillingDBLayer())
            {
                string param = "";
                for (int i = 0; i < parameters.Length; i++)
                {
                    //param = param + "{" + i.ToString() + "},";
                    param = param + "'" + parameters[i].ToString() + "',";
                }

                int index = param.LastIndexOf(',');

                string sql = "[" + spQuery + "] " + param.Substring(0, index);

                DataSet ds = new DataSet();
                //string strConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["DataLayer"].ConnectionString).ConnectionString;
                SqlConnection Conn = (System.Data.SqlClient.SqlConnection)dbContext.Database.Connection;
                try
                {
                    Conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, Conn);
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                }
                catch
                {
                    Conn.Close();
                }
                finally
                {
                    Conn.Close();
                }

                return ds;

            }

        }



        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    db.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }



    }
}