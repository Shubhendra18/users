﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace GroundWaterDept.Models
{
    public class ChangePass
    {
        public Int64 RegistrationID { get; set; }
        [Required(ErrorMessage = "Old Password required")]
        public string Password { get; set; }
        [Required(ErrorMessage = "New Password required")]
        public string NewPassword { get; set; }
        [Required(ErrorMessage = "Confirm Password required")]
        [CompareAttribute("NewPassword", ErrorMessage = "Password doesn't match.")]
        public string ConfirmPassowrd { get; set; }
    }
}