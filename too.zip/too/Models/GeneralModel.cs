﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Models
{
    public class GeneralModel
    {
       public Int16 CommonID { get; set; }
       public string Name { get; set; }
       public string TypeID { get; set; }   
    }
}