﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GroundWaterDept.DbRepository;
using System.ComponentModel.DataAnnotations;
namespace GroundWaterDept.Models
{
    public class ApplicationFormModel : LoginModel
    {
        //Registration 
        [Required(ErrorMessage = "Please Select Type")]
        public Int16 UserTypeID { get; set; }
        [Required(ErrorMessage = "Please Enter Applicant's Name")]
        public string ApplicantName { get; set; }
        [Required(ErrorMessage = "Please Select District Name")]
        public Int16 RDistrictID { get; set; }
        [Required(ErrorMessage = "Please Select Block Name")]
        public Int16 RBlockID { get; set; }
        [Required(ErrorMessage = "Please Enter Mobile No.")]
        public string MobileNo { get; set; }

        public Int64 RegistrationID { get; set; }
        public Int16 FormTypeID { get; set; }
        public Int16 UserCategoryID { get; set; }

        // public string Password { get; set; }

        //  [Required(ErrorMessage = "Please Enter Email ID")]
        public string EmailID { get; set; }

        //  public string IPAddress { get; set; }
        public bool IsMobileVerified { get; set; }

        public string OTP { get; set; }
        // Application
        //  public string AppNo { get; set; }
        public string OwnerName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string CareOF { get; set; }
        public Int16? Gender { get; set; }
        public string Nationality { get; set; }
        public string Address { get; set; }
        public Int16? StateID { get; set; }
        public Int16? DistrictID { get; set; }
        public string Pincode { get; set; }
        public Int16? P_DistrictID { get; set; }
        public Int16? P_BlockID { get; set; }
        public string PlotKhasraNo { get; set; }
        public Int16? IDProofID { get; set; }
        public string IDNumber { get; set; }
        public string IDPath { get; set; }
        public string MunicipalityCorporation { get; set; }
        public string WardHoldingNo { get; set; }
        public DateTime? DateOfConstruction { get; set; }
        public Int16? TypeOfTheWellID { get; set; }
        public decimal? DepthOfTheWell { get; set; }
        public bool? IsAdverseReport { get; set; }
        public string WaterQuality { get; set; }
        public Int16? TypeOfPumpID { get; set; }
        public decimal? LengthColumnPipe { get; set; }
        public decimal? PumpCapacity { get; set; }
        public decimal? HorsePower { get; set; }
        public Int16? OperationalDeviceID { get; set; }
        public DateTime? DateOfEnergization { get; set; }
        public Int16? PurposeOfWellID { get; set; }
        public decimal? AnnualRunningHours { get; set; }
        public decimal? DailyRunningHours { get; set; }
        public bool? IsPipedWaterSupply { get; set; }
        public string ModeOfTreatment { get; set; }
        public bool? IsObtainedNOC_UP { get; set; }
        public bool? IsRainWaterHarvesting { get; set; }
        public string Remarks { get; set; }
        public string Status { get; set; }
        public bool? IsHaveNocCertificate { get; set; }
        public string OtherTypeOfWell { get; set; }
        public decimal? DiameterOfDugWell { get; set; }
        public int? StructureofdugWell { get; set; }
        public decimal? ApproxLengthOfPipe { get; set; }
        public decimal? ApproxDiameterOfPipe { get; set; }
        public string IfAny { get; set; }
        public decimal? ApproxLengthOfStrainer { get; set; }
        public decimal? ApproxDiameterOfStrainer { get; set; }
        public int? MaterialOfPipe { get; set; }
        public int? MaterialOfStrainer { get; set; }
        [Required(ErrorMessage = "Required !")]
        public bool? GWDCertificate { get; set; } //Do you have Registration Certificate issued by Ground Water Department ?
        [Required(ErrorMessage = "Required !")]
        public bool? HaveNOC { get; set; } //Do you have N.O.C. Certificate ?
        public bool IAgree { get; set; }
        public bool? IsPaymentDone { get; set; }
        public bool? RegCertificateIssueByGWD { get; set; }
        public string RegCertificateNumber { get; set; }
        public DateTime? DateOfRegCertificateIssuance { get; set; }
        public DateTime? DateOfRegCertificateExpiry { get; set; }
        public string RegCertificatePath { get; set; }
        //Registration for well
        public int? Relation { get; set; }
        public string NameOfRelative { get; set; }
        public string AddressProofUrl { get; set; }
        public DateTime? DateOfNOCIssuanceByCGWD { get; set; }
        public DateTime? DateOfNOCExpiryByCGWD { get; set; }
        public string NOCCertificateNumberByCGWD { get; set; }
        public bool? CentralGroundWaterAuthority { get; set; }
        public string NOCByCGWDCertificatePath { get; set; }
        public bool? ByGroundWaterDepartment { get; set; }
        public string btnId { get; set; }
        public int? StepNo { get; set; }
        public List<ApplicationFormModel> objUserList { get; set; }
    }


    #region Ankita
    public class Dropdown
    {
        ApplicationFormDb objApplicationFormDb = new ApplicationFormDb();

        public SelectList LoadUserType()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("UT").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadGender()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("GN").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadNationality()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("NT").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadAddressProof()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("IDT").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadTypeOfWell()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("TW").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadMaterial()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("TM").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadTypeOfPump()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("TP").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadOperationalDevice()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("OD").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadPurposeOfWell()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("PW").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadRelation()
        {
            var data = objApplicationFormDb.LoadGeneralMasters("RN").Select(x => new SelectListItem { Value = x.CommonID.ToString(), Text = x.Name });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadState()
        {
            StateModel objmodel = new StateModel();
            objmodel.CountryID = 1;
            var data = objApplicationFormDb.LoadStateMaster(objmodel).Select(x => new SelectListItem { Value = x.StateID.ToString(), Text = x.StateName });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadDistrict(DistrictModel model)
        {
            var data = objApplicationFormDb.LoadDistrictMaster(model).Select(x => new SelectListItem { Value = x.DistrictID.ToString(), Text = x.DistrictName });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadBlock(BlockModel model)
        {
            var data = objApplicationFormDb.LoadBlockMaster(model).Select(x => new SelectListItem { Value = x.BlockID.ToString(), Text = x.BlockName });
            return new SelectList(data, "Value", "Text");
        }
        public SelectList LoadDistrictOfUP()
        {
            DistrictModel model = new DistrictModel();
            model.StateID = 34;
            var data = objApplicationFormDb.LoadDistrictMaster(model).Select(x => new SelectListItem { Value = x.DistrictID.ToString(), Text = x.DistrictName });
            return new SelectList(data, "Value", "Text");
        }

        public SelectList LoadYesNo()
        {
            return new SelectList(new SelectListItem[]{                  
                new SelectListItem{Text="Yes",Value="True"},
                new SelectListItem{Text="No",Value="False"},                
            }, "Value", "Text");
        }
    }
    #endregion

}