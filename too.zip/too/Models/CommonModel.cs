﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Models
{
    public class CommonModel
    {
        public string Relationof { get; set; }
        public string GenderName { get; set; }
        public string NationalityName { get; set; }
        public string StateName { get; set; }
        public string IDName { get; set; }
        public string BlockName { get; set; }
        public string PDistrictName { get; set; }
        public string ADistrictName { get; set; }
        public string WTName { get; set; }
        public string SMaterialName { get; set; }
        public string PMaterialName { get; set; }
        public string PumpTypeName { get; set; }
        public string ODName { get; set; }
        public string PWName { get; set; }
        public string RegDistrictName { get; set; }
        public string RegBlockName { get; set; }
    }
}