﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Models
{
    public class StateModel
    {
        public int StateID { get; set; }
        public int CountryID { get; set; }
        public string StateName { get; set; }
        public string StateNameHindi { get; set; }
        public bool isDeleted { get; set; }
        public int sortOrder { get; set; }

    }
}