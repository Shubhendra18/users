﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace GroundWaterDept.Models
{
    public class LoginModel:CommonModel
    {
        public Int64 UserID { get; set; }
        public string AppNo { get; set; }
        [Required(ErrorMessage = "Please Enter User ID")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Please Enter Password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please Enter Captcha")]
        public string captcha { get; set; }
        public string IPAddress { get; set; }
        public string DisplayPassword { get; set; }
       
        
    }
}