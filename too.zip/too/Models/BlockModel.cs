﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Models
{
    public class BlockModel
    {
        public int BlockID { get; set; }
        public int DistrictID { get; set; }
        public string BlockCode { get; set; }
        public string BlockName { get; set; }
        public string BlockNameHindi { get; set; }
        public string Status { get; set; }
    }
}