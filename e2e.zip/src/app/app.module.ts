import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LandingpageComponent } from './landingpage/landingpage.component';
import { SidebarComponent } from './Admin/sidebar.component';
import { NavbarComponent } from './Admin/navbar.component';
import { FooterComponent } from './Admin/footer.component';
import { InboxComponent } from './Admin/inbox.component';
import { ComposeComponent } from './Admin/compose.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from "@angular/common/http";
import { ApihandlerService } from './apihandler.service';
import { AdminloginComponent } from './admin/adminlogin.component';
import { UserloginComponent } from './User/userlogin.component';

@NgModule({
  declarations: [
    AppComponent,
    LandingpageComponent,
    SidebarComponent,
    NavbarComponent,
    FooterComponent,
    InboxComponent,
    ComposeComponent,
    AdminloginComponent,
    UserloginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    CommonModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [
    ApihandlerService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
