import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['../../assets/css/loginpage.css','../../assets/css/bootstrap.min.3.37.css']

})
export class AdminloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
