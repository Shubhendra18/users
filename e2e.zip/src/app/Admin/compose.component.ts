import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-compose',
  templateUrl: './compose.component.html',
  styles: []
})
export class ComposeComponent implements OnInit {

  constructor(private q: ApihandlerService, private toastr: ToastrService) { }

  ngOnInit() {
  }
  MailSend(mailForm) {
    console.log(mailForm);
    this.q.composemail(mailForm.value).subscribe(k => {
      console.log(k);
      this.toastr.success('Mail Send!', 'Success');
    });
  }
}
