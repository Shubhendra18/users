import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ComposeMailModel } from "../models/ComposeMail";
@Injectable({
  providedIn: 'root'
})
export class ApihandlerService {
  private baseUrl = "http://localhost:4876/"
  constructor(private http: HttpClient) { }
  composemail(mailForm: ComposeMailModel) {
    return this.http.post(this.baseUrl + "Mailer/ComposeMail", mailForm);
  }
  getmail() {
    return this.http.get(this.baseUrl + "Mailer/InboxMail");
  }
}
