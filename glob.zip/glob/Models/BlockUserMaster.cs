﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
namespace GroundWaterDept.Areas.Admin.Models
{
    public class BlockUserMaster
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string DisplayPassword { get; set; }
        [Required(ErrorMessage = "Mobile Is Requiered")]
        [StringLength(10, ErrorMessage = "The {0} must be {2} characters long.", MinimumLength = 10)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Mobile No. must be numeric")]
        public string Mobile { get; set; }
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        public bool? IsPassWordChange { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? FirstLogin { get; set; }
        public DateTime LastLoginTime { get; set; }
        public string LastLoginIP { get; set; }
        public int? WrongAttempt { get; set; }
        public bool? IsActive { get; set; }
        public int Rollid { get; set; }
        public DateTime CreatedOn { get; set; }
    }
    public class GetBlockUser
    {
        public int ID { get; set; }
        public string BlockName { get; set; }
        public string UserName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
    }
    public class GetBlockMaster
    {
        public List<SelectListItem> BlockName { get; set; }
        public int[] BlockID { get; set; }
    }
    public class AssignedBlockUser
    {
        public int ID { get; set; }
        public int UId { get; set; }
        public int BlockId { get; set; }
        public int DistrictRefid { get; set; }
    }
}