﻿using GroundWaterDept.Repository;
using SRVTextToImage;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GroundWaterDept.Areas.Admin.Models;
using System.Web.Security;
using GroundWaterDept.Models;
using System.Configuration;
using System.Data.SqlClient;
namespace GroundWaterDept.Areas.Admin.Controllers
{
    public class AdminController : Controller
    {
        #region Display Message
        public void DisplayMessage(string message, string midMsg, string messageStatus)
        {
            string status = messageStatus.ToLower();
            TempData["Message"] = message;
            TempData["messagemidStatus"] = midMsg;
            if (status == "s")
                TempData["messageStatus"] = "success";
            else if (status == "e")
                TempData["messageStatus"] = "error";
            else if (status == "w")
                TempData["messageStatus"] = "warning";
            else if (status == "i")
                TempData["messageStatus"] = "info";
        }
        public void DisplayMessageWithUrl(string message, string midMsg, string messageStatus, string messageUrl)
        {
            string status = messageStatus.ToLower();
            TempData["Message"] = message;
            TempData["messagemidStatus"] = midMsg;
            TempData["messageUrl"] = messageUrl;
            if (status == "s")
                TempData["messageStatus"] = "success";
            else if (status == "e")
                TempData["messageStatus"] = "error";
            else if (status == "w")
                TempData["messageStatus"] = "warning";
            else if (status == "i")
                TempData["messageStatus"] = "info";
        }
        #endregion
        #region Generate Captcha
        [AllowAnonymous]
        public FileResult Captcha()
        {
            string[] array = CaptchaImage.CreateRandomText(1);
            CaptchaRandomImage ci = new CaptchaRandomImage();
            this.Session["capimagetext"] = array[1].ToString();
            this.Session["captchaValue"] = array[0].ToString();
            ci.GenerateImage(this.Session["capimagetext"].ToString() + " =", 150, 40, Color.Black, Color.White);
            MemoryStream stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            return new FileStreamResult(stream, "image/png");

        }
        #endregion
        #region AdminLogin
        public ActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AdminLogin(AdminLogin model)
        {
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(Convert.ToString(model.captcha)))
                {
                    if (Convert.ToString(Session["captchaValue"]) == Convert.ToString(model.captcha))
                    {
                        if (!string.IsNullOrEmpty(model.UserName) && !string.IsNullOrEmpty(model.Password))
                        {
                            AdminContext adminContext = new AdminContext();
                            model.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(model.Password, "MD5");
                            model.LastLoginIP = CGeneral.getIPAddress();
                            List<AdminMasterModel> Data = adminContext.CheckAdminLogin(model).ToList();
                            if (Data.Count() > 0)
                            {
                                AdminSessionManager.UserName = Data[0].UserName;
                                AdminSessionManager.DistrictId = Data[0].Refid.ToString();
                                AdminSessionManager.Rollid = Data[0].Rollid.ToString();
                                return RedirectToAction("AdminDashboard", "Admin");
                            }
                            else
                            {
                                model.UserName = string.Empty;
                                model.Password = string.Empty;
                                DisplayMessage("Invalid", "User ID. or Password is incorrect!", "w");
                            }
                        }
                        else
                        {
                            model.UserName = string.Empty;
                            model.Password = string.Empty;
                            DisplayMessage("Required", "User ID.  or Password  can not be blank!", "w");
                        }
                    }
                    else
                    {
                        model.UserName = string.Empty;
                        model.Password = string.Empty;
                        DisplayMessage("Invalid Captcha text !!", " Please enter Calculated Value from Captcha Image.", "w"); ;
                    }
                }
                else
                {
                    model.UserName = string.Empty;
                    model.Password = string.Empty;
                    DisplayMessage("Warning", "Please Enter Captcha.", "W");
                }
            }
            return View();
        }
        #endregion
        public ActionResult AdminDashboard()
        {
            return View();
        }
        public ActionResult UserMaster()
        {
            AdminContext adminContext = new AdminContext();
            var data = adminContext.LoadBlockMaster(Convert.ToInt32(AdminSessionManager.DistrictId)).Select(x => new SelectListItem { Value = x.BlockID.ToString(), Text = x.BlockName }).ToList();
            //ViewBag.ddlblock = new SelectList(data, "Value", "Text");

            GetBlockMaster block = new GetBlockMaster();
            block.BlockName = data;

            List<GetBlockUser> blockData = adminContext.GetAllBlockUser(Convert.ToInt32(AdminSessionManager.DistrictId)).ToList();
            ViewBag.allBlockUser = blockData;
            return View(block);
        }
        [HttpPost]
        public ActionResult UserMaster(BlockUserMaster model, GetBlockMaster blockk, AssignedBlockUser assignuser)
        {
            AdminContext adminContext = new AdminContext();
            var data = adminContext.LoadBlockMaster(Convert.ToInt32(AdminSessionManager.DistrictId)).Select(x => new SelectListItem { Value = x.BlockID.ToString(), Text = x.BlockName }).ToList();
            //ViewBag.ddlblock = new SelectList(data, "Value", "Text");
            GetBlockMaster block = new GetBlockMaster();
            block.BlockName = data;
            if (blockk.BlockID != null)
            {
                model.UserName = AdminSessionManager.UserName + "-" + Guid.NewGuid().ToString("N").Substring(0, 5);
                model.DisplayPassword = CGeneral.GetRendomPassword(8);
                model.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(model.DisplayPassword, "MD5");
                model.Rollid = Convert.ToInt32(AdminSessionManager.Rollid);
                List<SelectListItem> selectedItems = block.BlockName.Where(p => blockk.BlockID.Contains(int.Parse(p.Value))).ToList();
                BlockUserMaster resData = null;
                resData = adminContext.CreateBlockUser(model);

                foreach (var selectedItem in selectedItems)
                {
                    assignuser.UId = resData.ID;
                    assignuser.BlockId = Convert.ToInt32(selectedItem.Value);
                    assignuser.DistrictRefid = Convert.ToInt32(AdminSessionManager.DistrictId);
                    AssignedBlockUser assignedBlockUser = null;
                    assignedBlockUser = adminContext.CreateAssignedBlock(assignuser);
                    if (resData != null)
                    {
                        String Msg = Convert.ToString(ConfigurationManager.AppSettings["BlockUserLoginMsg"]).Replace("[ID]", resData.UserName).Replace("[Pass]", resData.DisplayPassword);
                        SMSSender.SMSSend(Msg, resData.Mobile);
                        DisplayMessage("Success", "User Created successfully", "s");
                        HttpContext.Server.ScriptTimeout = 300;
                    }
                }

            }
            List<GetBlockUser> blockData = adminContext.GetAllBlockUser(Convert.ToInt32(AdminSessionManager.DistrictId)).ToList();
            ViewBag.allBlockUser = blockData;
            return RedirectToAction("UserMaster", "Admin");
        }
        [HttpPost]
        public ActionResult UpdateUserMaster(GetBlockUser user)
        {
            AdminContext adminContext = new AdminContext();
            GetBlockUser blockData = adminContext.UpdateBlockUser(user).FirstOrDefault();
            return new EmptyResult();
        }
        [HttpPost]
        public ActionResult DeleteUserMaster(int id)
        {
            AdminContext adminContext = new AdminContext();
            GetBlockUser blockDataa = adminContext.DeleteBlockUser(id).FirstOrDefault();
            List<GetBlockUser> blockData = adminContext.GetAllBlockUser(Convert.ToInt32(AdminSessionManager.DistrictId)).ToList();
            ViewBag.allBlockUser = blockData;
            return RedirectToAction("UserMaster", "Admin");
        }
        public ActionResult ApplicationForRegistrations()
        {
            AdminContext adminContext = new AdminContext();
            List<AllApplicationForRegistration> allregistrations = adminContext.GetAllApplicationForRegistration(Convert.ToInt32(AdminSessionManager.DistrictId)).ToList();
            ViewBag.allBlockUser = allregistrations;
            return View();
        }
        public ActionResult GetUserData()
        {
            AdminContext adminContext = new AdminContext();
            List<AllApplicationForRegistration> allregistrations = adminContext.GetAllApplicationForRegistration(Convert.ToInt32(AdminSessionManager.DistrictId)).ToList();
            //ViewBag.allBlockUser = allregistrations;
            return Json(allregistrations, JsonRequestBehavior.AllowGet);
        }
        public ActionResult ApplicationPreview(int id)
        {
            AdminContext adminContext = new AdminContext();
            ApplicationUser blockDataa = adminContext.GetApplicationDataById(id).FirstOrDefault();
            return View(blockDataa);
        }
        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Response.Cache.SetNoStore();
            return RedirectToAction("AdminLogin", "Admin", new { @returnUrl = "logout" });
        }
        #region ForgotPassword

        public ActionResult ForgetPassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgetPassword(AdminMasterModel model)
        {
            if (!string.IsNullOrEmpty(model.UserName))
            {
                AdminContext adminContext = new AdminContext();
                model.OTP = CGeneral.GetRendomNo(6);
                AdminSessionManager.UserName = model.UserName;
                var res = adminContext.ForgotPassword(model);
                if (res != null && res.Count > 0)
                {
                    AdminSessionManager.Id = res[0].ID.ToString();
                    AdminSessionManager.Mobile = res[0].Mobile.ToString();
                    String Msg = Convert.ToString(ConfigurationManager.AppSettings["AdminForgetMsg"]).Replace("[OTP]", model.OTP);
                    SMSSender.SMSSend(Msg, AdminSessionManager.Mobile);
                    DisplayMessageWithUrl("Success", "OTP has been sent to your mobile no. XXXXXX" + res[0].Mobile.Substring(6, 4) + " Please verify.", "s", Url.Action("ForgotPasswordOTPVerification", "Admin"));
                }
                else
                {
                    DisplayMessage("Invalid !", "The User ID you have entered is invalid, please enter correct User ID", "w");
                }
            }
            return View();
        }

        public ActionResult ForgotPasswordOTPVerification()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotPasswordOTPVerification(AdminMasterModel model)
        {
            if (!string.IsNullOrEmpty(model.OTP))
            {
                if (Convert.ToInt32(AdminSessionManager.Id) != 0)
                {
                    AdminContext adminContext = new AdminContext();
                    List<AdminMasterModel> objData = adminContext.VerifyAdminMobileOTP(Convert.ToInt32(AdminSessionManager.Id), model.OTP);
                    if (objData != null && objData.Count > 0)
                    {

                        model.DisplayPassword = CGeneral.GetRendomPassword(8);
                        model.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(model.DisplayPassword, "MD5");
                        model.ID = Convert.ToInt32(AdminSessionManager.Id);
                        model.Mobile = AdminSessionManager.Mobile;
                        model.UserName = AdminSessionManager.UserName;
                        var res = adminContext.UpdateAdminPassword(model);
                        if (res != null)
                        {
                            String Msg = Convert.ToString(ConfigurationManager.AppSettings["AdminResendPassMsg"]).Replace("[ID]", res.UserName).Replace("[Pass]", res.DisplayPassword);
                            SMSSender.SMSSend(Msg, AdminSessionManager.Mobile);
                            DisplayMessageWithUrl("Sent", "New password has been sent on your registered mobile no.XXXXXX" + AdminSessionManager.Mobile.Substring(6, 4) + " , Please login with your new password", "s", Url.Action("AdminLogin", "Admin"));
                        }
                        else
                        {
                            DisplayMessage("Warning", "Something went wrong please try after some time!", "w");
                        }

                    }
                    else
                    {
                        DisplayMessage("Warning", "OTP did not match,Please enter correct OTP.", "w");
                    }
                }
                else
                {
                    return RedirectToAction("AdminLogin");
                }
            }
            else
            {
                model.OTP = string.Empty;
                ModelState.AddModelError("OTP", "Please Enter OTP !!");
            }

            return View();
        }
        public ActionResult ReSendOTP()
        {
            if (AdminSessionManager.Mobile != null && Convert.ToInt32(AdminSessionManager.Id) != 0)
            {
                String Msg = string.Empty;
                AdminContext adminContext = new AdminContext();
                AdminMasterModel model = new AdminMasterModel();
                model.OTP = CGeneral.GetRendomNo(6);
                model.Mobile = AdminSessionManager.Mobile.ToString();
                model.ID = Convert.ToInt32(AdminSessionManager.Id);
                List<AdminMasterModel> objData = adminContext.UpdateAdminOTP(model);
                if (objData[0].Status == "Success")
                {

                    Msg = Convert.ToString(ConfigurationManager.AppSettings["AdminForgetMsg"]).Replace("[OTP]", model.OTP);
                    SMSSender.SMSSend(Msg, model.Mobile);
                    DisplayMessage("Resend !", "OTP has been sent to your mobile no. XXXXXX" + model.Mobile.Substring(6, 4) + " Please verify.", "s");
                }
            }
            else
            {
                DisplayMessage("Warning", "Something went wrong please try after some time!", "w");

            }

            return RedirectToAction("ForgotPasswordOTPVerification");
        }
        #endregion
    }
}
