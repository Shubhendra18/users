﻿$(document).ready(function () {
    if ($('#hdnDistrict').val() != "" || $('#hdnDistrict').val() != "0") {
        LoadDistrict($('#ddlState').val(), $('#hdnDistrict').val(), "ddlCity");
    }

    if ($('#hdnBlockId').val() != "" || $('#hdnBlockId').val() != "0") {
        LoadBlock($('#ddlP_District').val(), $('#hdnBlockId').val(), "ddlP_Block");
    }
});
$("#ddlState").change(function () {
    LoadDistrict($('#ddlState').val(), "", "ddlCity")
});


$("#ddlP_District").change(function () {
    LoadBlock($("#ddlP_District").val(), "", 'ddlP_Block');
})



function ValidateStep1() {
    var isOk = true;
    $("#btnId").val($("#btnStep1").attr("id"));
    $(".validate").each(function () {

        if ($(this).val() == '' || $(this).val() == 0) {
            $(this).focus().click();
            swal(
                'Required !', $(this).attr("message"), "warning"
            )
            isOk = false;
            return false;
        }
    });
    if (isOk) {
        if ($("input[name=Relation]:checked").val() == "" || $("input[name=Relation]:checked").val() == undefined) {
            swal('Required !', "Please Select Son of/ Daughter Of/ Wife of/ Husband of !!", "warning")
            isOk = false;
            return false;
        }
    }
    //if (isOk) {
    //    $("#stp2")[0].click();
    //    localStorage.setItem("id", "lnkstp2");
    //    return true;
    //}
    if (!isOk) {
        return false;
    }
}

function ValidateStep2() {
    var isOk = true;
    $("#btnId").val($("#btnStep2").attr("id"));
    $(".validate2").each(function () {

        if ($(this).val() == '' || $(this).val() == 0) {
            $(this).focus().click();
            swal(
                'Required !', $(this).attr("message"), "warning"
            )
            isOk = false;
            return false;
        }
    });
    if (isOk) {
        if ($("#ddlTypeOfWell").val() == "6") {
            if ($("#DiameterOfDugWell").val() == "") {
                $("#DiameterOfDugWell").focus();
                swal('Required !', "Please Enter Diameter of the Dug Well (m) !! ", "warning")
                isOk = false;
                return false;
            }
            if ($("input[name=StructureofdugWell]:checked").val() == "" || $("input[name=StructureofdugWell]:checked").val() == undefined) {
                $("#StructureofdugWell").focus();
                swal('Required !', "Please Select Type of Structure of the Dug Well !!", "warning")
                isOk = false;
                return false;
            }
        }
        else if ($("#ddlTypeOfWell").val() == "7") {
            $(".validateTubeWell").each(function () {

                if ($(this).val() == '' || $(this).val() == 0) {
                    $(this).focus().click();
                    swal(
                        'Required !', $(this).attr("message"), "warning"
                    )
                    isOk = false;
                    return false;
                }
            });
        }
    }
    //if (isOk) {
    //    $("#stp3")[0].click();
    //    localStorage.setItem("id", "lnkstp3");
    //    return true;
    //}
    if (!isOk) {
        return false;
    }
}

function ValidateStep3() {
    var isOk = true;
    $("#btnId").val($("#btnStep3").attr("id"));
    $(".validate3").each(function () {

        if ($(this).val() == '' || $(this).val() == 0) {
            $(this).focus().click();
            swal(
                'Required !', $(this).attr("message"), "warning"
            )
            isOk = false;
            return false;
        }
    });
    //if (isOk) {
    //    $("#stp4")[0].click();
    //    localStorage.setItem("id", "lnkstp4");
    //    return true;
    //}
    if (!isOk) {
        return false;
    }
}

function ValidateStep4() {
    var isOk = true;
    $("#btnId").val($("#btnStep4").attr("id"));
    $(".validate4").each(function () {

        if ($(this).val() == '' || $(this).val() == 0) {
            $(this).focus().click();
            swal(
                'Required !', $(this).attr("message"), "warning"
            )
            isOk = false;
            return false;
        }
    });
    if (isOk) {
        if ($("#ddlRegCertificateIssueByGWD").val() == "True") {
            $(".validateCert").each(function () {

                if ($(this).val() == '' || $(this).val() == 0) {
                    $(this).focus().click();
                    swal(
                        'Required !', $(this).attr("message"), "warning"
                    )
                    isOk = false;
                    return false;
                }
            });
        }
        if (!isOk) {
            return false;
        }
    }
    //if (isOk) {
    //    $("#stp5")[0].click();
    //    localStorage.setItem("id", "lnkstp5");
    //    return true;
    //}
    if (!isOk) {
        return false;
    }
}

function ValidateStep5() {
    var isOk = true;
    $("#btnId").val($("#btnStep5").attr("id"));

    if ($("input[name=IAgree]:checked").val() == "" || $("input[name=IAgree]:checked").val() == undefined) {
        swal('Required !', "Please Select I Agree before submitting the form !!", "warning")
        isOk = false;
        return false;
    }
    //if (isOk) {
    //    $("#stp6")[0].click();
    //    localStorage.setItem("id", "lnkstp6");
    //    return true;
    //}      
    if (!isOk) {
        return false;
    }
}


function LoadDistrict(stateId, districtId, dropdownId) {
    debugger;
    if (stateId != "") {
        var _Url = $("#" + dropdownId).attr("Url");
        $.ajax({
            url: _Url,
            data: { stateId: stateId },
            dataType: 'json',
            success: function (data) {
                if (data.length > 0) {
                    $("#" + dropdownId).children().remove().end().append($("<option></option>").val("").text("-Select-"));
                    $.each(data, function (key, value) {
                        $("#" + dropdownId).append($("<option></option>").val(value.DistrictID).text(value.DistrictName));
                    });
                    if (districtId != "") {
                        $("#" + dropdownId).val(districtId);
                    }
                }
                else {
                    $("#" + dropdownId).children().remove().end().append($("<option></option>").val("").text("-Select-"));
                }
            },
            error: function () {
            }
        });
    }
    else {
        $("#" + dropdownId).children().remove().end().append($("<option></option>").val("").text("-Select-"));
    }
}

function LoadBlock(districtId, BlockId, dropdownId) {
    debugger;
    if (districtId != "") {
        var _Url = $("#" + dropdownId).attr("Url");
        $.ajax({
            url: _Url,
            data: { districtId: districtId },
            dataType: 'json',
            success: function (data) {
                if (data.length > 0) {
                    $("#" + dropdownId).children().remove().end().append($("<option></option>").val("").text("-Select-"));
                    $.each(data, function (key, value) {
                        $("#" + dropdownId).append($("<option></option>").val(value.BlockID).text(value.BlockName));
                    });
                    if (BlockId != "") {
                        $("#" + dropdownId).val(BlockId);
                    }
                }
                else {
                    $("#" + dropdownId).children().remove().end().append($("<option></option>").val("").text("-Select-"));
                }
            },
            error: function () {
            }
        });
    }
    else {
        $("#" + dropdownId).children().remove().end().append($("<option></option>").val("").text("-Select-"));
    }
}


var baseUrl = $('base').attr('href');
var validFilesTypes = ["pdf", "PDF", "jpg", "JPG", "jpeg", "JPEG"];
var extn;
function CheckExtension(file) {
    var filePath = file.value;
    var ext = filePath.substring(filePath.lastIndexOf('.') + 1).toLowerCase();
    extn = ext
    // alert(ext);
    if (ext != '') {
        var isValidFile = false;
        for (var i = 0; i < validFilesTypes.length; i++) {
            if (ext == validFilesTypes[i]) {
                isValidFile = true;
                break;
            }
        }
        if (!isValidFile) {
            file.value = null;
            swal("Invalid File", "Please upload .jpg or .jpeg or .pdf file only.", "warning");
        }
    }
    return isValidFile;
}

var validFileSize = 2 * 1024 * 1024;

function CheckFileSize(file) {
    /*global document: false */
    var fileSize = file.files[0].size;
    var isValidFile = false;
    if (fileSize !== 0 && fileSize <= validFileSize) {
        isValidFile = true;
    }
    else {
        file.value = null;
        swal("Invalid File", 'Size of document should be less than or equal to 2 MB.', "warning");
    }

    return isValidFile;
}

function CheckFile(file) {
    var isValidFile = CheckExtension(file);
    if (isValidFile) {
        isValidFile = CheckFileSize(file);
    }
    return isValidFile;
}

function MultiAttachment(file, reportName) {
    var data = new FormData();
    var files = $(file).parent().find("input[type='file']").get(0).files;
    var id = $(file).next().attr('id');
    var num = $(file).attr('num');

    var validFile = CheckFile(file);
    //$('#reportName').html($('#' + id).html());

    var Url = 'ApplicationForm/UploadFile';
    if (validFile) {
        if (files.length > 0) {
            data.append("MyImages", files[0]);
            data.append("ReportName", reportName);
        }
        $.ajax({
            url: Url,
            type: "POST",
            processData: false,
            contentType: false,
            data: data,
            datatype: 'Json',
            success: function (response) {

                if (response[0] == 'Success') {

                    $('#' + id).val(baseUrl + 'Content/UploadedDocs/AddressIdProof/' + response[1]);
                    $('#View' + num).show();
                    $('#View' + num).prop("href", baseUrl + 'Content/UploadedDocs/AddressIdProof/' + response[1]);
                    swal("Uploaded", "Document Uploaded Successfully.", "success")

                } else {
                    $('#' + reportName).val('');
                    swal("Invalid File", response[0], "warning")

                }
            },
            error: function (er) {
                swal('Some problem occur !', '', 'error');

            }

        });

    }
};


$('.decimalOnly').bind('keypress', function (e) {
    if ((e.which < 48 || e.which > 57)) {
        if (e.which == 8 || e.which == 0 || e.which == 46 && this.value.split('.').length != 2) {
            return true;
        }
        else {
            return false;
        }
    }
});

$('.numberOnly').bind('keypress', function (e) {
    debugger;
    // console.log(e);
    if ((e.which < 48 || e.which > 57)) {
        if (e.which == 8 || e.which == 0) {
            return true;
        }
        else {
            return false;
        }
    }

});

$(document).on('focus', ".alphaNumeric", function () {
    $(this).bind("keypress", function (e) {

        if (e.altKey) {    //e.shiftKey || e.ctrlKey ||
            e.preventDefault();
        } else {
            var key = e.charCode;
            if (!((key == 8) || (key == 32) || (key == 46) || (key >= 65 && key <= 90) || (key >= 48 && key <= 57) || (key >= 96 && key <= 122))) {
                e.preventDefault();
            }
        }
    });
});

$(document).ready(function () {
    $(".alphaOnly").keypress(function (event) {
        var input = event.charCode;
        //alert(inputValue);
        if (!((input > 64 && input < 91) || (input > 96 && input < 123) || (input == 32) || (input == 0)) && input != 46) {
            event.preventDefault();
        }
    });
})

function validateMobileNumber(obj) {
    if ($(obj).val().length != 10) {
        $(obj).focus();
        swal("Invalid !", "Please enter valid Mobile No.!", "warning");
        $(obj).val("");
        return false;
    }
}

function validateEmailId(email) {
    debugger;
    var filter = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (filter.test($(email).val())) {
        return true;
    }
    else {
        $(email).focus();
        swal("Invalid !", "Please enter valid Email Id !", "warning");
        $(email).val("");
        return false;
    }
}

function validateAadhar(obj) {
    if ($(obj).val().length < 12) {
        $(obj).focus();
        swal("Invalid !", "Please enter valid Aadhar No.!", "warning");
        $(obj).val("");
        return false;
    }
}

function validPincode(obj) {
    if ($(obj).val().length != 6) {
        $(obj).focus();
        swal("Invalid !", "Please enter valid pin code.!", "warning");
        $(obj).val("");
        return false;
    }
}

//function RedirectTostep() {
//    if (ValidateStep1()) {
//        if (ValidateStep2()) {
//            if (ValidateStep3()) {
//                if (ValidateStep4()) {
//                    return true;
//                }
//                else {
//                    $("#stp4")[0].click();
//                    localStorage.setItem("id", "lnkstp4");
//                    return false;
//                }
//            }
//            else {
//                $("#stp3")[0].click();
//                localStorage.setItem("id", "lnkstp3");
//                return false;
//            }
//        }
//        else {
//            $("#stp2")[0].click();
//            localStorage.setItem("id", "lnkstp2");
//            return false;
//        }
//    }
//    else {
//        $("#stp1")[0].click();
//        localStorage.setItem("id", "lnkstp1");
//        return false;
//    }
//}