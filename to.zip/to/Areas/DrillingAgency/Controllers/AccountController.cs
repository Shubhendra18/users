﻿//using GroundWaterDept.Areas.DrillingAgency.DataLayer;
using GroundWaterDept.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using GroundWaterDept.Areas.DrillingAgency.Models;
using GroundWaterDept.Areas.DrillingAgency.DataLayer;
using GroundWaterDept.Repository;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing;
using SRVTextToImage;

using System.Web.Security;
using System.Web;
using WebMatrix.WebData;



namespace GroundWaterDept.Areas.DrillingAgency.Controllers
{
    public class AccountController : Controller
    {
        public DrillingDBLayer _context = new DrillingDBLayer();
        //public AccountController(DrillingDBLayer model)
        //{
        //    this._context = model;
        //}

        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult DrillingRegistration()
        {
            return View("DrillingRegistration");
        }

        [HttpPost]
        public ActionResult DrillingRegistration(LoginCreationModel model)
        {
            ModelState.Remove("OTP");
            ModelState.Remove("Username");
            ModelState.Remove("Password");
            ModelState.Remove("CapchtaText");
            if (ModelState.IsValid)
            {
                try
                {
                    var list = _context.Registration(model);
                    if (list != null && list.Count > 0)
                    {
                        if (list.FirstOrDefault().IsSuccess)
                        {
                            ModelState.AddModelError("OTP", "This is required");
                            model.TempRegNo = list.FirstOrDefault().TempRegNo;
                            return View("OTPVerification", model);
                        }
                        else
                        {
                            DisplayMessage("Unable to Complete Registration!!!", "", "w");
                        }
                    }
                }
                catch (Exception ex)
                {
                    DisplayMessage("some problem occur while registration!!!", "", "w");
                }
                return View("DrillingRegistration", model);
            }
            else
                return View("DrillingRegistration");
        }

        [HttpPost]
        public ActionResult OTPVerification(LoginCreationModel model)
        {

            if (!string.IsNullOrEmpty(model.OTP) && !string.IsNullOrEmpty(model.TempRegNo))
            {
                try
                {
                    model.pswdDisp = GroundWaterDept.Repository.CGeneral.RandomString(6);

                    var list = _context.OTPVerification(model);
                    if (list != null && list.Count > 0)
                    {
                        if (list.FirstOrDefault().IsSuccess)
                        {

                            DisplayMessage("Success!!!", "Online Registration of Drilling Agency has been complete successfully!!!. Username and Password has been sent on Registered Mobile No.and Email ID.", "s");
                            return RedirectToAction("Login");
                        }
                        else if (list.FirstOrDefault().IsValid)
                        {
                            DisplayMessage("One Time Password not match!!!", "", "w");
                            return View("OTPVerification", model);
                        }
                        else if (list.FirstOrDefault().IsNotMatch)
                        {
                            DisplayMessage("Invalid Request!!!", "", "s");
                            return View("OTPVerification", model);
                        }
                        else
                        {
                            DisplayMessage("Unable to Complete Registration!!!", "", "w");
                        }
                    }
                }
                catch (Exception ex)
                {
                    DisplayMessage("some problem occur while registration!!!", "", "w");
                }
            }
            return View("OTPVerification", model);
        }
        public JsonResult ValidateOTP(string AppNo)
        {
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult Login()
        {
            //MembershipUser msu = Membership.GetUser();

            string sKey = string.IsNullOrEmpty(SessionManager.AppNo) ? "" : SessionManager.AppNo;
            //HttpContext.Cache[sKey] = string.Empty;
            string sUser = Convert.ToString(HttpContext.Cache[sKey]);
            if (sUser == null || sUser == String.Empty)
            {
                // HttpContext.Cache.
                Session.Clear();
                Session.Abandon();
                FormsAuthentication.SignOut();
                this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
                this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                this.Response.Cache.SetNoStore();

            }
            else
            {
                return RedirectToAction("DashBoard", "Home");
            }
            return View();
        }
        [HttpPost]
        public ActionResult Login(UserLoginModel model)
        {
            if (!string.IsNullOrEmpty(model.Username) && !string.IsNullOrEmpty(model.Password) && !string.IsNullOrEmpty(model.CapchtaText))
            {
                try
                {



                    var list = _context.UserAuth(model);
                    if (list != null && list.Count > 0)
                    {
                        if (list.FirstOrDefault().IsSuccess)
                        {

                            SessionManager.AppNo = GroundWaterDept.Repository.EncriptionDecription.Encrypt(list.FirstOrDefault().AppNo.ToString());

                            string sKey = SessionManager.AppNo;

                            string sUser = Convert.ToString(HttpContext.Cache[sKey]);
                            //if (sUser == null || sUser == String.Empty)
                            //{
                                TimeSpan SessTimeOut = new TimeSpan(0, 0, 1, 0, 0);

                                HttpContext.Cache.Insert(sKey, sKey, null, DateTime.MaxValue, SessTimeOut,System.Web.Caching.CacheItemPriority.Default, null);

                               // Session["user"] = model.Username + model.Password;

                                SessionManager.UserId = list.FirstOrDefault().UserId;
                              
                                SessionManager.DisplayName = list.FirstOrDefault().CompanyName;
                                SessionManager.MobileNo = list.FirstOrDefault().MobileNo;
                                SessionManager.ApplicantName = list.FirstOrDefault().ApplicantName;
                                SessionManager.StepNo = list.FirstOrDefault().StepNo;
                                return RedirectToAction("DashBoard", "Home");
                            //}
                            //else
                            //{

                            //}
                        }
                        else if (list.FirstOrDefault().IsNotMatch)
                        {
                            DisplayMessage("Username or Password is incorrect!!!", "Please enter correct username and password", "w");
                            return View("Login", model);
                        }
                        else if (list.FirstOrDefault().IsInvalid)
                        {
                            DisplayMessage("Invalid Username!!!", "", "w");
                            return View("Login", model);
                        }
                        else
                        {
                            DisplayMessage("Unable to Login!!!", "", "w");
                        }
                    }
                    else
                    {
                        DisplayMessage("Invalid Username!!!", "", "w");
                        return View("Login", model);
                    }
                }
                catch (Exception ex)
                {
                    DisplayMessage("some problem occur while Login!!!", "", "w");
                }
            }
            return View();
        }
        public ActionResult Logout()
        {
            string sKey = string.IsNullOrEmpty(SessionManager.AppNo) ? "" : SessionManager.AppNo;
            HttpContext.Cache[sKey] = string.Empty;
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Response.Cache.SetNoStore();
            return RedirectToAction("Login", "Account", new { @returnUrl = "logout" });
        }

        #region CREATE CAPTCH
        [AllowAnonymous]
        public FileResult Captcha()
        {
            string[] array = CaptchaImage.CreateRandomText(1);
            CaptchaRandomImage ci = new CaptchaRandomImage();
            this.Session["capimagetext"] = array[1].ToString(); //ci.GetRandomString(5).ToUpper();
            this.Session["captchaValue"] = array[0].ToString();
            ci.GenerateImage(this.Session["capimagetext"].ToString() + " =", 150, 40, Color.Black, Color.White);
            MemoryStream stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            return new FileStreamResult(stream, "image/png");

        }


        #endregion
        public void DisplayMessage(string message, string messagemidStatus, string messageStatus_s_e_w_i_Or_blank)
        {
            string status = messageStatus_s_e_w_i_Or_blank.ToLower();
            TempData["Message"] = message;
            TempData["messagemidStatus"] = messagemidStatus;

            if (status == "s")
                TempData["messageStatus"] = "success";
            else if (status == "e")
                TempData["messageStatus"] = "error";
            else if (status == "w")
                TempData["messageStatus"] = "warning";
            else if (status == "i")
                TempData["messageStatus"] = "info";
        }
    }
}
