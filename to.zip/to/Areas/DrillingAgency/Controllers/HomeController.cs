﻿using GroundWaterDept.Areas.DrillingAgency.DataLayer;
using GroundWaterDept.Areas.DrillingAgency.Models;
using GroundWaterDept.Models;
using GroundWaterDept.Repository;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GroundWaterDept.Areas.DrillingAgency.Controllers
{
    [GroundWaterDept.FilterConfig.DrillingAgencySessionTimeout]
    public class HomeController : Controller
    {
        DrillingDBLayer ObjDbLayer = new DrillingDBLayer();
        //
        // GET: /DrillingAgency/Home/

        public ActionResult DashBoard()
        {

            return View();
        }
        public ActionResult ApplyOnline()
        {
            dynamic mymodel = new ExpandoObject();
            var list = ObjDbLayer.GetStepWiseRegistrationDetail<RegistrationModel>(SessionManager.AppNo, SessionManager.StepNo);
            list.AppNo = GroundWaterDept.Repository.EncriptionDecription.Encrypt(list.AppNo.ToString());

            return View(list);
        }
        public ActionResult LoadForm(string StepNo)
        {
            var list = ObjDbLayer.GetStepWiseRegistrationDetail<RegistrationModel>(SessionManager.AppNo, Convert.ToInt32(StepNo));
            list.AppNo = GroundWaterDept.Repository.EncriptionDecription.Encrypt(list.AppNo.ToString());
            if (StepNo == "0")
            {
                return PartialView("_ApplicantDetail", list);
            }
            else
                if (StepNo == "1")
                {
                    return PartialView("_districtDetail", list);
                }
                else
                    if (StepNo == "2")
                    {
                        return PartialView("_previewDetail", list);
                    }
                    else
                        if (StepNo == "3")
                        {
                            return PartialView("_Payment", list);
                        }
                        else
                        {
                            return PartialView("_ApplicantDetail", list);
                        }
        }

        public JsonResult GetDistrict(int StateId)
        {
            var list = ObjDbLayer.GetDistrictByState(StateId);
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult ApplyOnline(RegistrationModel model)
        {
            Dictionary<string, string> listMsg = new Dictionary<string, string>();
            try
            {
                ModelState.Remove("DrillingDistrict");
                ModelState.Remove("Districtids");
                ModelState.Remove("DrillingPurpose");
                ModelState.Remove("DrillingMachineDetail");
                if (ModelState.IsValid)
                {
                    if (model.AppNo == SessionManager.AppNo)
                    {
                        var list = ObjDbLayer.InsertUpdateApplicantDetail(model);
                        if (list != null && !string.IsNullOrEmpty(list.AppNo))
                        {
                            SessionManager.StepNo = list.StepNo;
                            listMsg.Add("SuccessMsg", "Step 1 has been Completed");
                            listMsg.Add("ErrorMsg", "");
                        }
                        else
                        {
                            listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
                        }
                    }
                    else
                    {

                        listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
                    }
                }
                else
                {

                    listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
                }
            }
            catch (Exception ex)
            {
                listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
            }

            //ERRORMSG: listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");

            return Json(listMsg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult ApplyOnlineStep2(RegistrationModel model)
        {
            Dictionary<string, string> listMsg = new Dictionary<string, string>();
            try
            {

                ModelState.AddModelError("Districtids", "required");
                ModelState.AddModelError("DrillingPurpose", "required");
                ModelState.AddModelError("DrillingMachineDetail", "required");

                if (!string.IsNullOrEmpty(model.DrillingMachineDetail)
                    && !string.IsNullOrEmpty(model.Districtids)
                    && !string.IsNullOrEmpty(model.DrillingPurpose))
                {
                    if (model.AppNo == SessionManager.AppNo)
                    {
                        var list = ObjDbLayer.InsertUpdateDistrictDetail(model);
                        if (list != null && !string.IsNullOrEmpty(list.AppNo))
                        {
                            SessionManager.StepNo = list.StepNo;
                            listMsg.Add("SuccessMsg", "Step 2 has been Completed");
                            listMsg.Add("ErrorMsg", "");
                        }
                        else
                        {
                            listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
                        }
                    }
                }
                else
                {
                    listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
                }
            }
            catch (Exception ex)
            {
                listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
            }
            return Json(listMsg, JsonRequestBehavior.AllowGet);
        }
        public ActionResult ApplyOnlineStep3(RegistrationModel model)
        {
            Dictionary<string, string> listMsg = new Dictionary<string, string>();
            try
            {

                if (model.AppNo == SessionManager.AppNo)
                {
                    var list = ObjDbLayer.FinalSubmitDetail(model);
                    if (list != null && !string.IsNullOrEmpty(list.AppNo))
                    {
                        SessionManager.StepNo = list.StepNo;
                        listMsg.Add("SuccessMsg", "Online Application for registration of Drilling Agency has been submitted.");
                        listMsg.Add("ErrorMsg", "");
                    }
                    else
                    {
                        listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
                    }
                }

                else
                {

                    listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
                }
            }
            catch (Exception ex)
            {
                listMsg.Add("ErrorMsg", "Some problem occurs while processing!!!");
            }
            return Json(listMsg, JsonRequestBehavior.AllowGet);
        }
        #region FileUpload
        public ActionResult FileUpload(HttpPostedFileBase filea)
        {
            // HttpPostedFileBase file=Request.Files[0];
            ValidateImage FileValidator = new ValidateImage();
            HttpPostedFileBase file = Request.Files[0];
            if (file != null)
            {
                string AppNo = GroundWaterDept.Repository.EncriptionDecription.Decrypt(SessionManager.AppNo);

                Dictionary<string, string> list = new Dictionary<string, string>();

                int maxLenght = 1024 * 1024 * 5;

                int _contentLength = file.ContentLength;
                string FilePath = Server.MapPath("../../Content/ReadWriteData/DrillingAgency/");
                string _fileName = Request.Form["FileName"].ToString();
                string _contentType = file.ContentType;
                string extn = Path.GetExtension(file.FileName);

                string Status = "";

                Status = FileValidator.ValidateImageExtWithSize(file, Convert.ToInt32(maxLenght));

                if (Status == "Valid")
                {

                    if (extn != string.Empty)
                    {
                        _fileName = _fileName + "_" + AppNo + "_" + DateTime.Now.Ticks.ToString() + extn;

                        if (!Directory.Exists(FilePath + AppNo))
                        {
                            Directory.CreateDirectory(FilePath + AppNo);
                        }
                        try
                        {
                            FilePath = FilePath + AppNo + "/";
                            file.SaveAs(FilePath + _fileName);
                            list.Add("fName", _fileName);
                            list.Add("errorMsg", "");
                        }
                        catch (Exception ex)
                        {
                            list.Add("fName", "");
                            //list.Add("errorMsg", "some problem occured while uploading image!!!");
                            list.Add("errorMsg", ex.Message + " " + ex.StackTrace);
                        }
                        return Json(list, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        _fileName = string.Empty;
                        FilePath = string.Empty;
                        list.Add("fName", "");
                        list.Add("errorMsg", "some problem occured while uploading file !!!");
                    }


                }
                else
                {
                    list.Add("fName", "");
                    list.Add("errorMsg", Status);
                    return Json(list, JsonRequestBehavior.AllowGet);
                }

            }

            return Json(null, JsonRequestBehavior.AllowGet);

        }
        #endregion
        public void DisplayMessage(string message, string messagemidStatus, string messageStatus_s_e_w_i_Or_blank)
        {
            string status = messageStatus_s_e_w_i_Or_blank.ToLower();
            TempData["Message"] = message;
            TempData["messagemidStatus"] = messagemidStatus;

            if (status == "s")
                TempData["messageStatus"] = "success";
            else if (status == "e")
                TempData["messageStatus"] = "error";
            else if (status == "w")
                TempData["messageStatus"] = "warning";
            else if (status == "i")
                TempData["messageStatus"] = "info";
        }
    }

}
