﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Areas.DrillingAgency.Models
{
    public class AccountModel
    {
    }
    public class Result
    {
        public bool IsExists { get; set; }
        public bool IsValid { get; set; }
        public bool IsSuccess { get; set; }
        public bool IsNotMatch { get; set; }
        public bool IsInvalid { get; set; }
        public bool IsInvalidCaptcha { get; set; }
    }
    public class LoginCreationModel : UserLoginModel
    {
        [Required(ErrorMessage = "This is required!!!")]
        public int UserTypeId { get; set; }

        //   public string AppNo { get; set; }

        [Required(ErrorMessage = "This is required!!!")]
        //[RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Use letters only please")]
        public string Name { get; set; }

        [Required(ErrorMessage = "This is required!!!")]
        [RegularExpression(@"^[a-zA-Z ]+$", ErrorMessage = "Use letters only please")]
        public string ApplicantName { get; set; }

        [Required(ErrorMessage = "This is required!!!")]
        public string FirmRegistrationNo { get; set; }

        [Required(ErrorMessage = "This is required!!!")]
        public string FirmGSTNo { get; set; }

        [Required(ErrorMessage = "This is required!!!")]
        [RegularExpression(@"[a-zA-Z]{5}\d{4}[a-zA-Z]{1}", ErrorMessage = "Invalid PAN Number")]
        public string FirmPANNo { get; set; }

        [Required(ErrorMessage = "This is required!!!")]
        [StringLength(10, ErrorMessage = "The {0} must be {2} characters long.", MinimumLength = 10)]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Mobile No. must be numeric")]
        public string MobileNo { get; set; }

        [Required(ErrorMessage = "This is required!!!")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string EmailId { get; set; }

        public string TempRegNo { get; set; }
    }
    public class OTPVerification : Result
    {
        [Required(ErrorMessage = "This is required!!!")]
        public string OTP { get; set; }
        public string AppNo { get; set; }

    }
    public class UserLoginModel : OTPVerification
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        public string pswdDisp { get; set; }
        [Required(ErrorMessage = "Enter Calculated Captcha Value")]
        public string CapchtaText { get; set; }
    }
    public class UserDetail : Result
    {
        public Int64 UserId { get; set; }
        public string AppNo { get; set; }
        public int UserTypeId { get; set; }
        public string CompanyName { get; set; }
        public string ApplicantName { get; set; }
        public string MobileNo { get; set; }
        public int StepNo { get; set; }
        //   public string ApplicantName { get; set; }

    }
    public class RegistrationModel : DistrictDetailModel
    {
        [Required]
        public string OwnerName { get; set; }
        [Required]
        public string SpouseTitle { get; set; }
        [Required]
        public string SpouseWardName { get; set; }
        [Required]
        public string DOB { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string Nationality { get; set; }
        [Required]
        public string PanCardPath { get; set; }
        [Required]
        public string GSTCertificatePath { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public int StateId { get; set; }
        [Required]
        public int DistrictId { get; set; }

        public string StateName { get; set; }
        public string DistrictName { get; set; }
        [Required]
        public string Pincode { get; set; }
        public string FirmPANNo { get; set; }
        public string FirmGSTNo { get; set; }
    }
    public class DistrictDetailModel : UserDetail
    {
        public int StateId { get; set; }

        public string DrillingDistrict { get; set; }
       
        public string Districtids { get; set; }
        
        public string DrillingPurpose { get; set; }
       
        public string DrillingMachineDetail { get; set; }
    }
    public class StateModel
    {
        public int StateId { get; set; }
        public string StateName { get; set; }
    }
    public class DistrictModel
    {
        public int DistrictId { get; set; }
        public string DistrictName { get; set; }
    }
}