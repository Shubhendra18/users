﻿using GroundWaterDept.Areas.DrillingAgency.DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GroundWaterDept.Areas.DrillingAgency.Models
{
    public class MasterModel
    {
        public SelectList LoadUserType()
        {
            return new SelectList(new SelectListItem[]{               
                new SelectListItem{Text="New User",Value="1"},
                new SelectListItem{Text="Existing User",Value="2"},
                 
            }, "Value", "Text");
        }
        public SelectList NameTitle()
        {
            return new SelectList(new SelectListItem[]{               
                new SelectListItem{Text="Son of",Value="S"},
                new SelectListItem{Text="Daughter of",Value="D"},
                new SelectListItem{Text="Wife of",Value="W"},
                new SelectListItem{Text="Husband of",Value="H"},
                 
            }, "Value", "Text");
        }
        public SelectList LoadGender()
        {
            return new SelectList(new SelectListItem[]{               
                new SelectListItem{Text="Male",Value="M"},
                new SelectListItem{Text="Female",Value="F"},
                 
            }, "Value", "Text");
        }
        public SelectList LoadNationality()
        {
            return new SelectList(new SelectListItem[]{               
                new SelectListItem{Text="Indian",Value="I"},
                new SelectListItem{Text="Other",Value="O"},
                 
            }, "Value", "Text");
        }
        public SelectList LoadState()
        {
            DrillingDBLayer objLayer = new DrillingDBLayer();
            return new SelectList(objLayer.GetState(), "StateId", "StateName");
        }
        public SelectList LoadGrillingPurpose()
        {
            return new SelectList(new SelectListItem[]{               
                new SelectListItem{Text="Government",Value="G"},
                new SelectListItem{Text="Private",Value="P"},
                new SelectListItem{Text="Both",Value="B"},
                 
            }, "Value", "Text");
        }
    }
}