﻿//$.get('../Account/GetLoginPage',  // url
//      function (data, textStatus, jqXHR) {  // success callback

//      });

//function LoadFrm(val) {
//    debugger
//    if (val == 'Login') {
//        debugger
//        $.get('../Account/GetLoginPage',  // url
//      function (data, textStatus, jqXHR) {  // success callback
//          $("#PageSection").html(data);
//      });
//    }
//    else {
//        debugger
//        $.get('../Account/GetRegistrationPage',  // url
//          function (data, textStatus, jqXHR) {  // success callback
//              debugger
//              $("#PageSection").html(data);
//          });
//    }
//}

//function Validate()
//{
//    debugger
//    return $("form").valid();

//}