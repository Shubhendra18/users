﻿function ValidateEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
};
function ValidatePanCard(panNo) {
    var regpan = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
    return regpan.test(panNo);

}
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function onlyAlphabets(e, t) {
    try {
        if (window.event) {
            var charCode = window.event.keyCode;
        }
        else if (e) {
            var charCode = e.which;
        }
        else { return true; }
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32))
            return true;
        else
            return false;
    }
    catch (err) {
        alert(err.Description);
    }
}

function FileUpload(Url, control, FileName) {
    debugger
    var file = new FormData();
    var fileUpload = $("#" + control).get(0).files
    var ArrDtls = [];
    if (fileUpload.length > 0) {
        file.append("Files", fileUpload[0]);
        file.append("FileName", FileName);
        $.ajax({
            url: Url,
            data: file,
            type: "POST",
            processData: false,
            contentType: false,
            async: false,
            success: function (result) {
                ArrDtls = result;
            },
            error: function (er) {
                alert(er)
            }
        });

    }
    return ArrDtls
}
function GetView(StepNo) {
    var data = [];
    for (var i = 0; i < 100000; i++) {
        var tmp = [];
        for (var i = 0; i < 100000; i++) {
            tmp[i] = 'hue';
        }
        data[i] = tmp;
    };
    //$("#LinkStep" + StepNo).parent().addClass("active");
    $.ajax({
        //xhr: function () {
        //    var xhr = new window.XMLHttpRequest();
        //    xhr.upload.addEventListener("progress", function (evt) {
        //        if (evt.lengthComputable) {
        //            var percentComplete = evt.loaded / evt.total;
        //            console.log(percentComplete);
        //            $('.progress').css({
        //                width: percentComplete * 100 + '%'
        //            });
        //            if (percentComplete === 1) {
        //                $('.progress').addClass('hide');
        //            }
        //        }
        //    }, false);
        //    xhr.addEventListener("progress", function (evt) {
        //        if (evt.lengthComputable) {
        //            var percentComplete = evt.loaded / evt.total;
        //            console.log(percentComplete);
        //            $('.progress').css({
        //                width: percentComplete * 100 + '%'
        //            });
        //        }
        //    }, false);
        //    return xhr;
        //},
        method: "get",
        url: "../Home/LoadForm",
        data: { StepNo: StepNo },
        beforeSend: function () {
            $("#divLoader").show();
        },
        complete: function () {
            $("#divLoader").hide();
        }, success: function (response) {

            $("#divLoader").hide();
            $("#tab-content").empty();
            $("#tab-content").html(response);


        }
    });
    setTimeout(SetActiveTab(StepNo), 500)
}




 





function SetActiveTab(StepNo) {

    $("[id *= LinkStep]").parent().parent().find('li').removeClass("active");
    if (StepNo == 0) {

        $('#LinkStep0').parent().addClass("active");
    } else
        if (StepNo == 1) {
            $('#LinkStep0').parent().addClass("complete");
            $('#LinkStep1').parent().addClass("active");
        } else
            if (StepNo == 2) {
                $('#LinkStep0').parent().addClass("complete");
                $('#LinkStep1').parent().addClass("complete");
                $('#LinkStep2').parent().addClass("active");
            } else
                if (StepNo == 3) {
                    $('#LinkStep0').parent().addClass("complete");
                    $('#LinkStep1').parent().addClass("complete");
                    $('#LinkStep2').parent().addClass("complete");
                    $('#LinkStep3').parent().addClass("active");
                }

}