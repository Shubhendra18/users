﻿using GroundWaterDept.Areas.DrillingAgency.Models;
using GroundWaterDept.Repository;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


namespace GroundWaterDept.Areas.DrillingAgency.DataLayer
{
    public class DrillingDBLayer : DbContext
    {
        public DrillingDBLayer()
            : base("GWDUPCon")
        { }

        //GenericRepository<AccountModel> objRepo = new GenericRepository<AccountModel>();

        public IList<LoginCreationModel> Registration(LoginCreationModel model)
        {
            object[] param = new object[] { model.UserTypeId, model.Name, model.ApplicantName, model.FirmRegistrationNo, model.FirmGSTNo, model.FirmPANNo, model.MobileNo, model.EmailId, GroundWaterDept.Repository.CGeneral.getIPAddress() };
            return new GenericRepository<LoginCreationModel>().GetAllData(param, "Proc_DrillingRegistration").ToList();
        }
        public IList<LoginCreationModel> OTPVerification(LoginCreationModel model)
        {
            object[] param = new object[] { model.TempRegNo, model.OTP, GroundWaterDept.Repository.EncriptionDecription.EncryptionMD5(model.pswdDisp.ToString()), model.pswdDisp, GroundWaterDept.Repository.CGeneral.getIPAddress() };
            return new GenericRepository<LoginCreationModel>().GetAllData(param, "Proc_OTPVerification").ToList();
        }
        public IList<UserDetail> UserAuth(UserLoginModel model)
        {
            object[] param = new object[] { model.Username, GroundWaterDept.Repository.EncriptionDecription.EncryptionMD5(model.Password.ToString()), GroundWaterDept.Repository.CGeneral.getIPAddress() };
            return new GenericRepository<UserDetail>().GetAllData(param, "proc_DrillingUserAuth").ToList();
        }
        public IList<StateModel> GetState()
        {
            object[] param = new object[] { };
            return new GenericRepository<StateModel>().GetAllData(param, "Proc_GetState").ToList();
        }
        public IList<DistrictModel> GetDistrictByState(int StateID)
        {
            object[] param = new object[] { StateID };
            return new GenericRepository<DistrictModel>().GetAllData(param, "Proc_GetDistrictByState").ToList();
        }
        public T GetStepWiseRegistrationDetail<T>(string AppNo, int stepNo) where T : class
        {
            object[] param = new object[] { GroundWaterDept.Repository.EncriptionDecription.Decrypt(AppNo), stepNo };
            return new GenericRepository<T>().InsertWithList(param, "Proc_GetApplicantDetail");
        }
        #region Step1
        public RegistrationModel InsertUpdateApplicantDetail(RegistrationModel model)
        {
            object[] param = new object[] { GroundWaterDept.Repository.EncriptionDecription.Decrypt(model.AppNo), model.OwnerName, model.SpouseTitle, model.SpouseWardName, model.DOB, model.Gender, model.Nationality, model.PanCardPath, model.GSTCertificatePath, model.Address, model.StateId, model.DistrictId, model.Pincode, GroundWaterDept.Repository.CGeneral.getIPAddress() };
            return new GenericRepository<RegistrationModel>().InsertWithList(param, "Proc_InsertUpdateApplicantDetail");
        }
        #endregion
        #region Step2
        public RegistrationModel InsertUpdateDistrictDetail(DistrictDetailModel model)
        {
            object[] param = new object[] { GroundWaterDept.Repository.EncriptionDecription.Decrypt(model.AppNo), model.Districtids, model.DrillingMachineDetail, model.DrillingPurpose, GroundWaterDept.Repository.CGeneral.getIPAddress() };
            return new GenericRepository<RegistrationModel>().InsertWithList(param, "Proc_InsertUpdateDistrictDetail");
        }
        #endregion
        #region Step3
        public RegistrationModel FinalSubmitDetail(RegistrationModel model)
        {
            object[] param = new object[] { GroundWaterDept.Repository.EncriptionDecription.Decrypt(model.AppNo), GroundWaterDept.Repository.CGeneral.getIPAddress() };
            return new GenericRepository<RegistrationModel>().InsertWithList(param, "Proc_FinalSubmitDrillingDetail");
        }
        #endregion

    }
}