﻿using System.Web.Mvc;

namespace GroundWaterDept.Areas.DrillingAgency
{
    public class DrillingAgencyAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "DrillingAgency";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "DrillingAgency_default",
                "DrillingAgency/{controller}/{action}/{id}",
                new { action = "Login", id = UrlParameter.Optional },
                new[] { "GroundWaterDept.Areas.DrillingAgency.Controllers" }
            );
        }
    }
}
