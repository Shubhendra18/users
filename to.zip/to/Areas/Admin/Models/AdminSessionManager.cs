﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Areas.Admin.Models
{
    public class AdminSessionManager
    {

        public static void RemoveSession()
        {
            try
            {
                HttpContext.Current.Session.Clear();
                HttpContext.Current.Session.Abandon();
                HttpContext.Current.Session.RemoveAll();
            }
            catch
            { }
        }
        public static string UserName
        {
            get
            {
                if (HttpContext.Current.Session["UserName"] != null)
                {
                    return Convert.ToString((HttpContext.Current.Session["UserName"]));
                }
                else
                {
                    return "";
                }
            }
            set
            {
                HttpContext.Current.Session["UserName"] = value;
            }
        }
        public static string Id
        {
            get
            {
                if (HttpContext.Current.Session["Id"] != null)
                {
                    return Convert.ToString((HttpContext.Current.Session["Id"]));
                }
                else
                {
                    return "";
                }
            }
            set
            {
                HttpContext.Current.Session["Id"] = value;
            }
        }
        public static string Mobile
        {
            get
            {
                if (HttpContext.Current.Session["Mobile"] != null)
                {
                    return Convert.ToString((HttpContext.Current.Session["Mobile"]));
                }
                else
                {
                    return "";
                }
            }
            set
            {
                HttpContext.Current.Session["Mobile"] = value;
            }
        }

        public static string DistrictId
        {
            get
            {
                if (HttpContext.Current.Session["DistrictId"] != null)
                {
                    return Convert.ToString((HttpContext.Current.Session["DistrictId"]));
                }
                else
                {
                    return "";
                }
            }
            set
            {
                HttpContext.Current.Session["DistrictId"] = value;
            }
        }
        public static string Rollid
        {
            get
            {
                if (HttpContext.Current.Session["Rollid"] != null)
                {
                    return Convert.ToString((HttpContext.Current.Session["Rollid"]));
                }
                else
                {
                    return "";
                }
            }
            set
            {
                HttpContext.Current.Session["Rollid"] = value;
            }
        } 
    }
}