﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Areas.Admin.Models
{
    public class ApplicationUser
    {
        
        public Int64 RegistrationID { get; set; }
        public string AppNo { get; set; }
        public Int16 FormTypeID { get; set; }
        public Int16 UserCategoryID { get; set; }
        public string EmailID { get; set; }
        public bool IsMobileVerified { get; set; }
        public string OTP { get; set; }
        public string OwnerName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string CareOF { get; set; }
        public Int16? Gender { get; set; }
        public string Nationality { get; set; }
        public string Address { get; set; }
        public Int16? StateID { get; set; }
        public Int16? DistrictID { get; set; }
        public string Pincode { get; set; }
        public Int16? P_DistrictID { get; set; }
        public Int16? P_BlockID { get; set; }
        public string PlotKhasraNo { get; set; }
        public Int16? IDProofID { get; set; }
        public string IDNumber { get; set; }
        public string IDPath { get; set; }
        public string MunicipalityCorporation { get; set; }
        public string WardHoldingNo { get; set; }
        public DateTime? DateOfConstruction { get; set; }
        public Int16? TypeOfTheWellID { get; set; }
        public decimal? DepthOfTheWell { get; set; }
        public bool? IsAdverseReport { get; set; }
        public string WaterQuality { get; set; }
        public Int16? TypeOfPumpID { get; set; }
        public decimal? LengthColumnPipe { get; set; }
        public decimal? PumpCapacity { get; set; }
        public decimal? HorsePower { get; set; }
        public Int16? OperationalDeviceID { get; set; }
        public DateTime? DateOfEnergization { get; set; }
        public Int16? PurposeOfWellID { get; set; }
        public decimal? AnnualRunningHours { get; set; }
        public decimal? DailyRunningHours { get; set; }
        public bool? IsPipedWaterSupply { get; set; }
        public string ModeOfTreatment { get; set; }
        public bool? IsObtainedNOC_UP { get; set; }
        public bool? IsRainWaterHarvesting { get; set; }
        public string Remarks { get; set; }
        public string Status { get; set; }
        public bool? IsHaveNocCertificate { get; set; }
        public string OtherTypeOfWell { get; set; }
        public decimal? DiameterOfDugWell { get; set; }
        public int? StructureofdugWell { get; set; }
        public decimal? ApproxLengthOfPipe { get; set; }
        public decimal? ApproxDiameterOfPipe { get; set; }
        public string IfAny { get; set; }
        public decimal? ApproxLengthOfStrainer { get; set; }
        public decimal? ApproxDiameterOfStrainer { get; set; }
        public int? MaterialOfPipe { get; set; }
        public int? MaterialOfStrainer { get; set; }
        public bool? GWDCertificate { get; set; } //Do you have Registration Certificate issued by Ground Water Department ?
        public bool? HaveNOC { get; set; } //Do you have N.O.C. Certificate ?
        public bool IAgree { get; set; }
        public bool? IsPaymentDone { get; set; }
        public bool? RegCertificateIssueByGWD { get; set; }
        public string RegCertificateNumber { get; set; }
        public DateTime? DateOfRegCertificateIssuance { get; set; }
        public DateTime? DateOfRegCertificateExpiry { get; set; }
        public string RegCertificatePath { get; set; }
        //Registration for well
        public int? Relation { get; set; }
        public string NameOfRelative { get; set; }
        public string AddressProofUrl { get; set; }
        public DateTime? DateOfNOCIssuanceByCGWD { get; set; }
        public DateTime? DateOfNOCExpiryByCGWD { get; set; }
        public string NOCCertificateNumberByCGWD { get; set; }
        public bool? CentralGroundWaterAuthority { get; set; }
        public string NOCByCGWDCertificatePath { get; set; }
        public bool? ByGroundWaterDepartment { get; set; }
    }
    public class AllApplicationForRegistration
    {
        public Int64 RegistrationID { get; set; }
        public string AppNo { get; set; }
        public string ApplicationType { get; set; }
        public string UserType { get; set; }
        public string ApplicantName { get; set; }
        public bool? HaveNOC { get; set; }
        public string WellType { get; set; }
        public string Status { get; set; }
    }
}