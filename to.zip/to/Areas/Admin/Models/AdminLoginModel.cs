﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GroundWaterDept.Areas.Admin.Models
{
    public class AdminMasterModel
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string DisplayPassword { get; set; }
        public bool? IsPassWordChange { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? FirstLogin { get; set; }
        public DateTime LastLoginTime { get; set; }
        public string LastLoginIP { get; set; }
        public int? WrongAttempt { get; set; }
        public bool? IsActive { get; set; }
        public int Rollid { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public Int64 Refid { get; set; }
        public string OTP { get; set; }
        public bool? IsMobileVerified { get; set; }
        public string Status { get; set; }

    }

    public class AdminLogin
    {
        public int ID { get; set; }
        [Required(ErrorMessage = "Please Enter User ID", AllowEmptyStrings = false)]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Please Enter Password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please Enter Captcha")]
        public string captcha { get; set; }
        public string LastLoginIP { get; set; }
        public string DisplayPassword { get; set; }
    }
}