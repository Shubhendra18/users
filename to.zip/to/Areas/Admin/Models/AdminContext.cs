﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data.SqlClient;
using GroundWaterDept.Models;
namespace GroundWaterDept.Areas.Admin.Models
{
    public class AdminContext : DbContext
    {
        public AdminContext()
            : base("GWDUPCon")
        { }
        public List<AdminMasterModel> CheckAdminLogin(AdminLogin model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@UserName",Value=model.UserName},
                new SqlParameter {ParameterName="@Password",Value=model.Password},   
                new SqlParameter {ParameterName="@LastLoginIP",Value=model.LastLoginIP},   
                 };
            var sqlQuery = @"proc_CheckAdminLogin @UserName,@Password,@LastLoginIP";
            var res = this.Database.SqlQuery<AdminMasterModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<BlockModel> LoadBlockMaster(int DistrictID)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@DistrictID",Value=DistrictID},                           
            };
            var sqlQuery = @"proc_SelectBlockMaster @DistrictID";
            var res = this.Database.SqlQuery<BlockModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public BlockUserMaster CreateBlockUser(BlockUserMaster model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@UserName",Value=model.UserName},
                new SqlParameter {ParameterName="@MobileNo",Value=model.Mobile},
                new SqlParameter {ParameterName="@Email",Value=model.Email},
                new SqlParameter {ParameterName="@Password",Value=model.Password},
                new SqlParameter {ParameterName="@DisplayPassword",Value=model.DisplayPassword},
                new SqlParameter {ParameterName="@Rollid",Value=model.Rollid},   
                 };
            var sqlQuery = @"proc_CreateBlockUser @UserName,@MobileNo,@Email,@Password,@DisplayPassword,@Rollid";
            var res = this.Database.SqlQuery<BlockUserMaster>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public AssignedBlockUser CreateAssignedBlock(AssignedBlockUser model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@BlockId",Value=model.BlockId},
                new SqlParameter {ParameterName="@Uid",Value=model.UId},
                new SqlParameter {ParameterName="@DistrictRefid",Value=model.DistrictRefid},   
                 };
            var sqlQuery = @"proc_AssignedBlock @BlockId,@Uid,@DistrictRefid";
            var res = this.Database.SqlQuery<AssignedBlockUser>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<GetBlockUser> GetAllBlockUser(int DistrictID)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@DistrictID",Value=DistrictID},                           
            };
            var sqlQuery = @"proc_GetBlockUser @DistrictID";
            var res = this.Database.SqlQuery<GetBlockUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<GetBlockUser> UpdateBlockUser(GetBlockUser model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@ID",Value=model.ID},             
                new SqlParameter {ParameterName="@Mobile",Value=model.Mobile},                           
                new SqlParameter {ParameterName="@Email",Value=model.Email},                           
            };
            var sqlQuery = @"proc_UpdateBlockUser @ID, @Mobile,@Email";
            var res = this.Database.SqlQuery<GetBlockUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<GetBlockUser> DeleteBlockUser(int ID)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@ID",Value=ID},                           
            };
            var sqlQuery = @"proc_DeleteBlockUser @ID";
            var res = this.Database.SqlQuery<GetBlockUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<ApplicationUser> GetApplicationDataById(int RegistrationID)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@RegistrationID",Value=RegistrationID},                           
            };
            var sqlQuery = @"proc_GetApplicationForRegistrationByID @RegistrationID";
            var res = this.Database.SqlQuery<ApplicationUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<AllApplicationForRegistration> GetAllApplicationForRegistration(int DistrictID)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@DistrictID",Value=DistrictID},                           
            };
            var sqlQuery = @"proc_GetApplicationForRegistration @DistrictID";
            var res = this.Database.SqlQuery<AllApplicationForRegistration>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<AdminMasterModel> ForgotPassword(AdminMasterModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@UserName",Value=model.UserName}, 
                new SqlParameter {ParameterName="@Otp",Value=model.OTP},   
            };
            var sqlQuery = @"proc_GetAdminMobileNoUpdateOtp @UserName,@Otp";
            var res = this.Database.SqlQuery<AdminMasterModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<AdminMasterModel> VerifyAdminMobileOTP(int RegistrationID, string OTP)
        {
            try
            {
                var sqlParam = new SqlParameter[] { 
                     new SqlParameter {ParameterName="@OTP",Value=OTP},
                new SqlParameter {ParameterName="@ID",Value=RegistrationID},                  
                 };
                var sqlQuery = @"proc_VerifyAdminMobile @OTP,@ID";
                var res = this.Database.SqlQuery<AdminMasterModel>(sqlQuery, sqlParam).ToList();
                return res;
            }
            catch { return null; }
        }
        public AdminMasterModel UpdateAdminPassword(AdminMasterModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@MobileNo",Value=model.Mobile},
                new SqlParameter {ParameterName="@Password",Value=model.Password},
                new SqlParameter {ParameterName="@DisplayPassword",Value=model.DisplayPassword}, 
                new SqlParameter {ParameterName="@Id",Value=model.ID},  
                new SqlParameter {ParameterName="@UserName",Value=model.UserName},    
            };
            var sqlQuery = @"proc_UpdateAdminPassword @MobileNo,@Password,@DisplayPassword,@Id,@UserName";
            var res = this.Database.SqlQuery<AdminMasterModel>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<AdminMasterModel> UpdateAdminOTP(AdminMasterModel Model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@OTP",Value=Model.OTP},
                new SqlParameter {ParameterName="@ID",Value=Model.ID},
                 };
            var sqlQuery = @"proc_UpdateAdminOTP @OTP,@ID";
            var res = this.Database.SqlQuery<AdminMasterModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
    }
}
