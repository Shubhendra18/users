﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Data.Entity;
using GroundWaterDept.Models;
using System.Configuration;
namespace GroundWaterDept.DbRepository
{
    public class ApplicationFormDb : DbContext
    {
        public ApplicationFormDb()
            : base("GWDUPCon")
        {
        }
        public List<ApplicationFormModel> InsertRegistrationDetails(ApplicationFormModel Model, int procid)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@procId",Value=procid},
                new SqlParameter {ParameterName="@FormTypeID",Value=Model.FormTypeID},
                new SqlParameter {ParameterName="@UserCategoryID",Value=Model.UserCategoryID},
                new SqlParameter {ParameterName="@UserTypeID",Value=Model.UserTypeID},
                new SqlParameter {ParameterName="@RDistrictID",Value=Model.RDistrictID},
                new SqlParameter {ParameterName="@RBlockID",Value=Model.RBlockID},
                new SqlParameter {ParameterName="@EmailID",Value=Model.EmailID??""},
                new SqlParameter {ParameterName="@ApplicantName",Value=Model.ApplicantName},
                new SqlParameter {ParameterName="@IPAddress",Value=Model.IPAddress},
                new SqlParameter {ParameterName="@IsMobileVerified",Value=Model.IsMobileVerified},
                new SqlParameter {ParameterName="@MobileNo",Value=Model.MobileNo??""},
                new SqlParameter {ParameterName="@OTP",Value=Model.OTP},
                new SqlParameter {ParameterName="@GWDCertificate",Value=Model.GWDCertificate??false},
                new SqlParameter {ParameterName="@HaveNOC",Value=Model.HaveNOC??false},                 
                 };
            var sqlQuery = @"proc_UserRegistration @ProcId, @FormTypeID, @UserCategoryID, @UserTypeID, @RDistrictID, @RBlockID,@EmailID,@ApplicantName,@IPAddress,@IsMobileVerified,@MobileNo,@OTP,@GWDCertificate,@HaveNOC ";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<ApplicationFormModel> UpdateUserOTP(ApplicationFormModel Model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@OTP",Value=Model.OTP},
                new SqlParameter {ParameterName="@RegistrationID",Value=Model.RegistrationID},
                 };
            var sqlQuery = @"proc_UpdateOTP @OTP,@RegistrationID";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<ApplicationFormModel> CheckUserLogin(LoginModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@UserName",Value=model.UserName},
                new SqlParameter {ParameterName="@Password",Value=model.Password},   
                new SqlParameter {ParameterName="@IPAddress",Value=model.IPAddress},   
                 };
            var sqlQuery = @"proc_CheckUserLogin @UserName,@Password,@IPAddress";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<ApplicationFormModel> VerifyUserMobileOTP(Int64 RegistrationID, string OTP)
        {
            try
            {
                var sqlParam = new SqlParameter[] { 
                     new SqlParameter {ParameterName="@OTP",Value=OTP},
                new SqlParameter {ParameterName="@RegistrationID",Value=RegistrationID},                  
                 };
                var sqlQuery = @"proc_VerifyUserMobile @OTP,@RegistrationID";
                var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).ToList();
                return res;
            }
            catch { return null; }
        }
        public ApplicationFormModel UpdateApplicationForm(ApplicationFormModel Model, int procid)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@RegistrationID",Value=Model.RegistrationID},
                new SqlParameter {ParameterName="@OwnerName",Value=Model.OwnerName??""},
                new SqlParameter {ParameterName="@DateOfBirth",Value=Model.DateOfBirth ?? Convert.ToDateTime("01/01/1900")},
                new SqlParameter {ParameterName="@CareOF",Value=Model.CareOF??""},
                new SqlParameter {ParameterName="@Gender",Value=Model.Gender??0},
                new SqlParameter {ParameterName="@Nationality",Value=Model.Nationality??""},
                new SqlParameter {ParameterName="@Address",Value=Model.Address??""},
                new SqlParameter {ParameterName="@StateID",Value=Model.StateID??0},
                new SqlParameter {ParameterName="@DistrictID",Value=Model.DistrictID??0},
                new SqlParameter {ParameterName="@Pincode",Value=Model.Pincode??""},
                new SqlParameter {ParameterName="@P_DistrictID",Value=Model.RDistrictID},
                new SqlParameter {ParameterName="@P_BlockID",Value=Model.RBlockID},
                new SqlParameter {ParameterName="@PlotKhasraNo",Value=Model.PlotKhasraNo??""},
                new SqlParameter {ParameterName="@IDProofID",Value=Model.IDProofID ?? 0},
                new SqlParameter {ParameterName="@IDNumber",Value=Model.IDNumber??""},
                new SqlParameter {ParameterName="@IDPath",Value=Model.IDPath??""},
                new SqlParameter {ParameterName="@MunicipalityCorporation",Value=Model.MunicipalityCorporation??""},
                new SqlParameter {ParameterName="@WardHoldingNo",Value=Model.WardHoldingNo??""},
                new SqlParameter {ParameterName="@DateOfConstruction",Value=Model.DateOfConstruction ?? Convert.ToDateTime("01/01/1900")},
                new SqlParameter {ParameterName="@TypeOfTheWellID",Value=Model.TypeOfTheWellID ?? 0},
                new SqlParameter {ParameterName="@DepthOfTheWell",Value=Model.DepthOfTheWell??0},
                new SqlParameter {ParameterName="@IsAdverseReport",Value=Model.IsAdverseReport??false},
                new SqlParameter {ParameterName="@WaterQuality",Value=Model.WaterQuality??""},
                new SqlParameter {ParameterName="@TypeOfPumpID",Value=Model.TypeOfPumpID ?? 0},
                new SqlParameter {ParameterName="@LengthColumnPipe",Value=Model.LengthColumnPipe??0},
                new SqlParameter {ParameterName="@PumpCapacity",Value=Model.PumpCapacity??0},
                new SqlParameter {ParameterName="@HorsePower",Value=Model.HorsePower??0},
                new SqlParameter {ParameterName="@OperationalDeviceID",Value=Model.OperationalDeviceID ?? 0},
                new SqlParameter {ParameterName="@DateOfEnergization",Value=Model.DateOfEnergization ?? Convert.ToDateTime("01/01/1900")},
                new SqlParameter {ParameterName="@PurposeOfWellID",Value=Model.PurposeOfWellID ?? 0},
                new SqlParameter {ParameterName="@AnnualRunningHours",Value=Model.AnnualRunningHours??0},
                new SqlParameter {ParameterName="@DailyRunningHours",Value=Model.DailyRunningHours??0},
                new SqlParameter {ParameterName="@IsPipedWaterSupply",Value=Model.IsPipedWaterSupply ?? false},
                new SqlParameter {ParameterName="@ModeOfTreatment",Value=Model.ModeOfTreatment??""},
                new SqlParameter {ParameterName="@IsObtainedNOC_UP",Value=Model.IsObtainedNOC_UP  ?? false},
                new SqlParameter {ParameterName="@IsRainWaterHarvesting",Value=Model.IsRainWaterHarvesting ?? false},
                new SqlParameter {ParameterName="@Remarks",Value=Model.Remarks??""},
                new SqlParameter {ParameterName="@ProcId",Value=procid},   
                new SqlParameter {ParameterName="@Relation",Value=Model.Relation??0},
                new SqlParameter {ParameterName="@DiameterOfDugWell",Value=Model.DiameterOfDugWell??0},
                new SqlParameter {ParameterName="@StructureofdugWell",Value=Model.StructureofdugWell??0},
                new SqlParameter {ParameterName="@ApproxLengthOfPipe",Value=Model.ApproxLengthOfPipe??0},
                new SqlParameter {ParameterName="@ApproxDiameterOfPipe",Value=Model.ApproxDiameterOfPipe??0},
                new SqlParameter {ParameterName="@IfAny",Value=Model.IfAny??""},
                new SqlParameter {ParameterName="@ApproxLengthOfStrainer",Value=Model.ApproxLengthOfStrainer??0},
                new SqlParameter {ParameterName="@ApproxDiameterOfStrainer",Value=Model.ApproxDiameterOfStrainer??0},
                new SqlParameter {ParameterName="@MaterialOfPipe",Value=Model.MaterialOfPipe??0},
                new SqlParameter {ParameterName="@MaterialOfStrainer",Value=Model.MaterialOfStrainer??0},
                new SqlParameter {ParameterName="@RegCertificateIssueByGWD",Value=Model.RegCertificateIssueByGWD ?? false},
                new SqlParameter {ParameterName="@RegCertificateNumber",Value=Model.RegCertificateNumber??""},
                new SqlParameter {ParameterName="@DateOfRegCertificateIssuance",Value=Model.DateOfRegCertificateIssuance?? Convert.ToDateTime("01/01/1900")},
                new SqlParameter {ParameterName="@DateOfRegCertificateExpiry",Value=Model.DateOfRegCertificateExpiry?? Convert.ToDateTime("01/01/1900")},
                new SqlParameter {ParameterName="@RegCertificatePath",Value=Model.RegCertificatePath??""},
                new SqlParameter {ParameterName="@IAgree",Value=Model.IAgree},
                new SqlParameter {ParameterName="@StepNo",Value=Model.StepNo},
                new SqlParameter {ParameterName="@CentralGroundWaterAuthority",Value=Model.CentralGroundWaterAuthority ?? false},
                new SqlParameter {ParameterName="@NOCCertificateNumberByCGWD",Value=Model.NOCCertificateNumberByCGWD??""},
                new SqlParameter {ParameterName="@DateOfNOCIssuanceByCGWD",Value=Model.DateOfNOCIssuanceByCGWD?? Convert.ToDateTime("01/01/1900")},
                new SqlParameter {ParameterName="@DateOfNOCExpiryByCGWD",Value=Model.DateOfNOCExpiryByCGWD?? Convert.ToDateTime("01/01/1900")},
                new SqlParameter {ParameterName="@NOCByCGWDCertificatePath",Value=Model.NOCByCGWDCertificatePath??""},
            };
            var sqlQuery = @"proc_InsertUpdateApplication @RegistrationID,@OwnerName,@DateOfBirth,@CareOF,@Gender,@Nationality,@Address,@StateID,@DistrictID,@Pincode,@P_DistrictID,@P_BlockID,@PlotKhasraNo,@IDProofID,@IDNumber,@IDPath,@MunicipalityCorporation,@WardHoldingNo,@DateOfConstruction,@TypeOfTheWellID,@DepthOfTheWell,@IsAdverseReport,@WaterQuality,@TypeOfPumpID,@LengthColumnPipe,@PumpCapacity,@HorsePower,@OperationalDeviceID,@DateOfEnergization,@PurposeOfWellID,@AnnualRunningHours,@DailyRunningHours,@IsPipedWaterSupply,@ModeOfTreatment,@IsObtainedNOC_UP,@IsRainWaterHarvesting,
@Remarks,@ProcId,@Relation,@DiameterOfDugWell,@StructureofdugWell,@ApproxLengthOfPipe,@ApproxDiameterOfPipe,@IfAny,@ApproxLengthOfStrainer,@ApproxDiameterOfStrainer,@MaterialOfPipe,@MaterialOfStrainer,@RegCertificateIssueByGWD,@RegCertificateNumber,@DateOfRegCertificateIssuance,
@DateOfRegCertificateExpiry,@RegCertificatePath,@IAgree,@StepNo,@CentralGroundWaterAuthority,@NOCCertificateNumberByCGWD,@DateOfNOCIssuanceByCGWD,@DateOfNOCExpiryByCGWD,@NOCByCGWDCertificatePath";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public ApplicationFormModel LoadApplicationForm(ApplicationFormModel Model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@RegistrationID",Value=Model.RegistrationID},                           
            };
            var sqlQuery = @"proc_LoadApplicationForm @RegistrationID";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<GeneralModel> LoadGeneralMasters(string Model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@TypeID",Value=Model},                           
            };
            var sqlQuery = @"proc_SelectCommonMaster @TypeID";
            var res = this.Database.SqlQuery<GeneralModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<StateModel> LoadStateMaster(StateModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@CountryID",Value=model.CountryID},                           
            };
            var sqlQuery = @"proc_SelectStateMaster @CountryID";
            var res = this.Database.SqlQuery<StateModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<DistrictModel> LoadDistrictMaster(DistrictModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@StateID",Value=model.StateID},                           
            };
            var sqlQuery = @"proc_SelectDistrictMaster @StateID";
            var res = this.Database.SqlQuery<DistrictModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<BlockModel> LoadBlockMaster(BlockModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@DistrictID",Value=model.DistrictID},                           
            };
            var sqlQuery = @"proc_SelectBlockMaster @DistrictID";
            var res = this.Database.SqlQuery<BlockModel>(sqlQuery, sqlParam).ToList();
            return res;
        }

        public List<BlockModel> CheckBlockMaster(BlockModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@BlockID",Value=model.BlockID},                           
            };
            var sqlQuery = @"proc_CheckBlockMaster @BlockID";
            var res = this.Database.SqlQuery<BlockModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<LoginModel> ChangePassword(ChangePass model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@RegistrationID",Value=model.RegistrationID},  
                new SqlParameter {ParameterName="@Password",Value=model.Password},  
                new SqlParameter {ParameterName="@ConfirmPassowrd",Value=model.ConfirmPassowrd},          
            };
            var sqlQuery = @"proc_UpdatePassword @RegistrationID,@Password,@ConfirmPassowrd";
            var res = this.Database.SqlQuery<LoginModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public ApplicationFormModel CheckPassword(ChangePass model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@Password",Value=model.Password},   
                 new SqlParameter {ParameterName="@RegistrationID",Value=model.RegistrationID},            
            };
            var sqlQuery = @"proc_CheckPassword @Password,@RegistrationID";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<ApplicationFormModel> ForgotPassword(ApplicationFormModel model, int ProcId)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@UserName",Value=model.UserName}, 
                new SqlParameter {ParameterName="@Otp",Value=model.OTP},   
                new SqlParameter {ParameterName="@ProcId",Value=ProcId},          
            };
            var sqlQuery = @"proc_GetUserMobileNoUpdateOtp @UserName,@Otp,@ProcId";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public ApplicationFormModel CreateUserLogin(ApplicationFormModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@MobileNo",Value=model.MobileNo},
                new SqlParameter {ParameterName="@Password",Value=model.Password},
                new SqlParameter {ParameterName="@DisplayPassword",Value=model.DisplayPassword}, 
                new SqlParameter {ParameterName="@RegistrationID",Value=model.RegistrationID},
               
            };
            var sqlQuery = @"proc_CreateUserLogin @MobileNo,@Password,@DisplayPassword,@RegistrationID";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public ApplicationFormModel UpdateUserPassword(ApplicationFormModel model, int ProcId)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@MobileNo",Value=model.MobileNo},
                new SqlParameter {ParameterName="@Password",Value=model.Password},
                new SqlParameter {ParameterName="@DisplayPassword",Value=model.DisplayPassword}, 
                new SqlParameter {ParameterName="@RegistrationID",Value=model.RegistrationID},  
                new SqlParameter {ParameterName="@UserName",Value=model.UserName},    
                new SqlParameter {ParameterName="@ProcId",Value=ProcId},
            };
            var sqlQuery = @"proc_UpdateUserPassword @MobileNo,@Password,@DisplayPassword,@RegistrationID,@UserName,@ProcId";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }

        public List<ApplicationFormModel> GetallUsernameByMobile(ApplicationFormModel model)
        {
            var sqlParam = new SqlParameter[] { 
                new SqlParameter {ParameterName="@Mobile",Value=model.MobileNo},                      
            };
            var sqlQuery = @"proc_getAllUserByMobile @Mobile";
            var res = this.Database.SqlQuery<ApplicationFormModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
    }
}