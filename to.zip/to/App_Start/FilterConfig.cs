﻿using GroundWaterDept.Areas.Admin.Models;
using GroundWaterDept.Repository;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;

namespace GroundWaterDept
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
        public class DrillingAgencySessionTimeout : ActionFilterAttribute
        {
            public override void OnActionExecuting(ActionExecutingContext filterContext)
            {

                HttpContext ctx = HttpContext.Current;
                string ResqUrl = ctx.Request.CurrentExecutionFilePath;

                if ((string.IsNullOrEmpty(SessionManager.AppNo) || SessionManager.AppNo == "" || SessionManager.AppNo == "0"))
                {
                    FormsAuthentication.SignOut();
                    HttpContext.Current.Session.Clear();
                    HttpContext.Current.Session.Abandon();
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "Login" }, { "controller", "Account" }, { "Area", "DrillingAgency" }, { "returnUrl", "SessionTimeout" } });  //new RedirectResult("~/Home/Login");
                    //filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "Login" }, { "controller", "Account" }, { "returnUrl", filterContext.HttpContext.Request.RawUrl }});  //new RedirectResult("~/Home/Login");

                    return;
                }
                base.OnActionExecuting(filterContext);
            }
        }

  
    }
}