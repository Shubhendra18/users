﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;
using System.Web.Security;
using System.Xml.Linq;
//using AttributeRouting;
//using AttributeRouting.Web;
//using CrystalDecisions.CrystalReports.Engine;
using GroundWaterDept.DbRepository;
using GroundWaterDept.Filters;
using GroundWaterDept.Models;
using GroundWaterDept.Repository;
using Newtonsoft.Json;
using SRVTextToImage;

namespace GroundWaterDept.Controllers
{
    public class ApplicationFormController : Controller
    {
        #region Display Message
        public void DisplayMessage(string message, string midMsg, string messageStatus_s_e_w_i_Or_blank)
        {
            string status = messageStatus_s_e_w_i_Or_blank.ToLower();
            TempData["Message"] = message;
            TempData["messagemidStatus"] = midMsg;
            if (status == "s")
                TempData["messageStatus"] = "success";
            else if (status == "e")
                TempData["messageStatus"] = "error";
            else if (status == "w")
                TempData["messageStatus"] = "warning";
            else if (status == "i")
                TempData["messageStatus"] = "info";
        }

        public void DisplayMessageWithUrl(string message, string midMsg, string messageStatus_s_e_w_i_Or_blank, string messageUrl)
        {
            string status = messageStatus_s_e_w_i_Or_blank.ToLower();
            TempData["Message"] = message;
            TempData["messagemidStatus"] = midMsg;
            TempData["messageUrl"] = messageUrl;
            if (status == "s")
                TempData["messageStatus"] = "success";
            else if (status == "e")
                TempData["messageStatus"] = "error";
            else if (status == "w")
                TempData["messageStatus"] = "warning";
            else if (status == "i")
                TempData["messageStatus"] = "info";
        }
        #endregion

        #region CREATE CAPTCH
        [AllowAnonymous]
        public FileResult Captcha()
        {
            string[] array = CaptchaImage.CreateRandomText(1);
            CaptchaRandomImage ci = new CaptchaRandomImage();
            this.Session["capimagetext"] = array[1].ToString(); //ci.GetRandomString(5).ToUpper();
            this.Session["captchaValue"] = array[0].ToString();
            ci.GenerateImage(this.Session["capimagetext"].ToString() + " =", 150, 40, Color.Black, Color.White);
            MemoryStream stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            return new FileStreamResult(stream, "image/png");
        }
        #endregion

        public ActionResult VerifyOTP()
        {
            return View();
        }

        [HttpPost]
        public ActionResult VerifyOTP(ApplicationFormModel model)
        {
            if (!String.IsNullOrEmpty(model.OTP))
            {
                if (SessionManager.RegistrationID != 0)
                {
                    ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
                    List<ApplicationFormModel> objData = ObjApplicationFormDb.VerifyUserMobileOTP(SessionManager.RegistrationID, model.OTP);
                    if (objData.Count > 0)
                    {
                        if (objData[0].Status == "Success")
                        {
                            model.DisplayPassword = CGeneral.GetRendomPassword(8);
                            model.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(model.DisplayPassword, "MD5");
                            model.RegistrationID = SessionManager.RegistrationID;
                            model.MobileNo = SessionManager.MobileNo;
                            ApplicationFormModel objDataLogin = ObjApplicationFormDb.CreateUserLogin(model);
                            if (objDataLogin != null)
                            {
                                String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserLoginMsg"]).Replace("[ID]", objDataLogin.UserName).Replace("[Pass]", objDataLogin.DisplayPassword);
                                SMSSender.SMSSend(Msg, objData[0].MobileNo); // Only OTP to verify Mobile Number.
                                DisplayMessageWithUrl("Success", "OTP Verified successfully,And login detail sent to your mobile no. XXXXXX" + model.MobileNo.Substring(6, 4), "s", Url.Action("UserLogin", "ApplicationForm", new { FT = EncriptionDecription.Encrypt(SessionManager.FormTypeID.ToString()) }));
                                HttpContext.Server.ScriptTimeout = 300;
                                // return RedirectToAction("UserLogin");
                            }
                            else
                            {
                                DisplayMessageWithUrl("Warning", "Something went wrong please try after some time!", "w", Url.Action("VerifyOTP", "ApplicationForm"));
                                //   return RedirectToAction("VerifyOTP");
                            }
                        }
                    }
                    else
                    {
                        DisplayMessageWithUrl("Warning", "OTP did not match,Please try again!", "w", Url.Action("VerifyOTP", "ApplicationForm"));
                        //  return RedirectToAction("VerifyOTP");
                    }
                }
            }
            return View();
        }

        public ActionResult UserLogin(string FT)
        {
            if (!string.IsNullOrEmpty(FT))
            {
                Int16 FormType = Convert.ToInt16(EncriptionDecription.Decrypt(FT));
                SessionManager.RegistrationID = 0;
                SessionManager.UserCategoryID = 0;
                SessionManager.UserTypeID = 0;
                SessionManager.FormTypeID = FormType;
                SessionManager.AppNo = string.Empty;
                SessionManager.ApplicantName = string.Empty;
                return View();
            }
            else
            {
                return View("TestLinks");
            }
        }

        [HttpPost]
        public ActionResult UserLogin(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(Convert.ToString(model.captcha)))
                {
                    if (Convert.ToString(Session["captchaValue"]) == Convert.ToString(model.captcha))
                    {
                        if (!string.IsNullOrEmpty(model.UserName) && !string.IsNullOrEmpty(model.Password))
                        {
                            ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
                            model.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(model.Password, "MD5");
                            model.IPAddress = CGeneral.getIPAddress();
                            List<ApplicationFormModel> Data = ObjApplicationFormDb.CheckUserLogin(model).ToList();
                            if (Data.Count() > 0)
                            {
                                SessionManager.RegistrationID = Data[0].RegistrationID;
                                SessionManager.UserCategoryID = Data[0].UserCategoryID;
                                SessionManager.UserTypeID = Data[0].UserTypeID;
                                //  SessionManager.FormTypeID = Data[0].FormTypeID;
                                SessionManager.AppNo = Data[0].AppNo.ToString();
                                SessionManager.ApplicantName = Data[0].ApplicantName.ToString();
                                HttpContext.Session["step"] = Data[0].StepNo;
                                if (SessionManager.FormTypeID == 22 || SessionManager.FormTypeID == 23)
                                {
                                    return RedirectToAction("Dashboard", "ApplicationForm");
                                }
                                //else if (SessionManager.FormTypeID == 1)
                                //{
                                //    return RedirectToAction("UserApplicationForm", "ApplicationForm");
                                //}
                            }
                            else
                            {
                                model.UserName = string.Empty;
                                model.Password = string.Empty;
                                DisplayMessage("Invalid", "User ID. or Password is incorrect!", "w");
                            }
                        }
                        else
                        {
                            model.UserName = string.Empty;
                            model.Password = string.Empty;
                            DisplayMessage("Required", "User ID.  or Password  not Blank Wrong!", "w");
                        }
                    }
                    else
                    {
                        model.UserName = string.Empty;
                        model.Password = string.Empty;
                        DisplayMessage("Invalid Captcha text !!", " Please enter Calculated Value from Captcha Image.", "w"); ;
                    }
                }
                else
                {
                    model.UserName = string.Empty;
                    model.Password = string.Empty;
                    DisplayMessage("Warning", "Please Enter Captcha.", "W");
                }
            }
            return View();
        }

        public ActionResult UserRegistration(string FT)
        {
            if (!string.IsNullOrEmpty(FT))
            {
                Int16 FormType = Convert.ToInt16(EncriptionDecription.Decrypt(FT));
                SessionManager.FormTypeID = FormType;
                return View();
            }
            else
            {
                return View("TestLinks");
            }
        }

        [HttpPost]
        public ActionResult UserRegistration(ApplicationFormModel model)
        {
            //if (ModelState.IsValid)
            //{    
            model.FormTypeID = SessionManager.FormTypeID;
            if (model.MobileNo != null && model.RDistrictID != 0 && model.RBlockID != 0 && model.ApplicantName != null && model.UserTypeID != 0 && model.FormTypeID != 0)
            {
                model.OTP = CGeneral.GetRendomNo(6);
                model.IPAddress = CGeneral.getIPAddress();
                ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
                if (SessionManager.FormTypeID == 22)
                {
                    model.UserCategoryID = 25;
                }
                model.objUserList = ObjApplicationFormDb.GetallUsernameByMobile(model);
                //if (model.objUserList != null && model.objUserList.Count > 0)
                //{
                //    return PartialView("_RegistrationUserList", model);
                //}
                //else
                //{
                List<ApplicationFormModel> objData = ObjApplicationFormDb.InsertRegistrationDetails(model, 1);
                if (objData != null && objData.Count > 0)
                {
                    SessionManager.RegistrationID = objData[0].RegistrationID;
                    SessionManager.MobileNo = objData[0].MobileNo.ToString();
                    String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserRegMsg"]).Replace("[OTP]", model.OTP);
                    SMSSender.SMSSend(Msg, model.MobileNo); // Only OTP to verify Mobile Number.
                    DisplayMessageWithUrl("Success", "OTP has been sent to your mobile no. XXXXXX" + model.MobileNo.Substring(6, 4) + " Please verify.", "s", Url.Action("VerifyOTP", "ApplicationForm"));
                    HttpContext.Server.ScriptTimeout = 300;
                    // return RedirectToAction("VerifyOTP", "ApplicationForm");
                }
                else
                {
                    DisplayMessage("Warning", "Something went wrong please try after some time!", "w");
                }
                // }
            }
            //}
            return View();
        }

        public ActionResult UserApplicationForm()
        {
            ApplicationFormModel objData = new ApplicationFormModel();
            if (SessionManager.RegistrationID != 0)
            {
                ApplicationFormModel model = new ApplicationFormModel();
                Dropdown DropModel = new Dropdown();
                ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
                model.RegistrationID = SessionManager.RegistrationID;
                objData = ObjApplicationFormDb.LoadApplicationForm(model);
                SelectList items = DropModel.LoadRelation();
                ViewBag.Relation = items;
                if (objData == null)
                {
                    objData = new ApplicationFormModel();
                }
            }
            else
            {
                return RedirectToAction("UserLogin", "ApplicationForm", new { FT = EncriptionDecription.Encrypt(SessionManager.FormTypeID.ToString()) });
            }
            return View(objData);
        }

        [HttpPost]
        public ActionResult UserApplicationForm(ApplicationFormModel model)
        {
            ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
            Dropdown DropModel = new Dropdown();
            model.RegistrationID = SessionManager.RegistrationID;
            if (model.btnId == "btnStep1")
            {
                model.StepNo = 1;
                HttpContext.Session["Step"] = 1;
            }
            if (model.btnId == "btnStep2")
            {
                model.StepNo = 2;
                HttpContext.Session["Step"] = 2;
            }
            if (model.btnId == "btnStep3")
            {
                model.StepNo = 3;
                HttpContext.Session["Step"] = 3;
            }
            if (model.btnId == "btnStep4")
            {
                model.StepNo = 4;
                HttpContext.Session["Step"] = 4;
            }
            if (model.btnId == "btnStep5")
            {
                model.StepNo = 5;
                HttpContext.Session["Step"] = 5;
            }
            ApplicationFormModel objData = ObjApplicationFormDb.UpdateApplicationForm(model, 1);
            DisplayMessage("Success", "Details submitted successfully, do you want to proceed to the next step?", "s");
            SelectList items = DropModel.LoadRelation();
            ViewBag.Relation = items;
            if (objData == null)
            {
                objData = new ApplicationFormModel();
            }
            else if (objData.IAgree)
            {
                String Msg = Convert.ToString(ConfigurationManager.AppSettings["AppNoMsg"]).Replace("[AppNo]", objData.AppNo);
                SMSSender.SMSSend(Msg, model.MobileNo); // Only OTP to verify Mobile Number;
            }
            return View(objData);
        }


        public ActionResult ReSendOTP(string Req = "")
        {
            if (SessionManager.MobileNo != null && SessionManager.RegistrationID != 0)
            {
                String Msg = string.Empty;
                ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
                ApplicationFormModel model = new ApplicationFormModel();
                model.OTP = CGeneral.GetRendomNo(6);
                model.MobileNo = SessionManager.MobileNo.ToString();
                model.RegistrationID = SessionManager.RegistrationID;
                List<ApplicationFormModel> objData = ObjApplicationFormDb.UpdateUserOTP(model);
                if (objData[0].Status == "Success")
                {
                    if (Req == "F")
                    {
                        Msg = Convert.ToString(ConfigurationManager.AppSettings["UserForgetMsg"]).Replace("[OTP]", model.OTP);
                        SMSSender.SMSSend(Msg, model.MobileNo); // Only OTP to verify Mobile Number.
                        DisplayMessage("Resend !", "OTP has been sent to your mobile no. XXXXXX" + model.MobileNo.Substring(6, 4) + " Please verify.", "s");
                        return RedirectToAction("ForgotPasswordOTPVerification");
                    }
                    else
                    {
                        Msg = Convert.ToString(ConfigurationManager.AppSettings["UserRegMsg"]).Replace("[OTP]", model.OTP);
                        SMSSender.SMSSend(Msg, model.MobileNo); // Only OTP to verify Mobile Number.
                        DisplayMessage("Resend !", "OTP has been sent to your mobile no. XXXXXX" + model.MobileNo.Substring(6, 4) + " Please verify.", "s");
                        return RedirectToAction("VerifyOTP");
                    }
                }
            }
            else
            {
                DisplayMessage("Warning", "Something went wrong please try after some time!", "w");

            }

            return RedirectToAction("UserLogin", "ApplicationForm", new { FT = EncriptionDecription.Encrypt(SessionManager.FormTypeID.ToString()) });
        }

        public ActionResult NocApplicationForm()
        {
            ApplicationFormModel objData = new ApplicationFormModel();
            if (SessionManager.RegistrationID != 0)
            {
                ApplicationFormModel model = new ApplicationFormModel();
                Dropdown DropModel = new Dropdown();
                ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
                model.RegistrationID = SessionManager.RegistrationID;
                objData = ObjApplicationFormDb.LoadApplicationForm(model);
                SelectList items = DropModel.LoadRelation();
                ViewBag.Relation = items;
                if (objData == null)
                {
                    objData = new ApplicationFormModel();
                }
            }
            else
            {
                return RedirectToAction("UserLogin", "ApplicationForm", new { FT = EncriptionDecription.Encrypt(SessionManager.FormTypeID.ToString()) });
            }
            return View(objData);
        }

        [HttpPost]
        public ActionResult NocApplicationForm(ApplicationFormModel model)
        {
            ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
            Dropdown DropModel = new Dropdown();
            model.RegistrationID = SessionManager.RegistrationID;
            if (model.btnId == "btnStep1")
            {
                model.StepNo = 1;
                HttpContext.Session["Step"] = 1;
            }
            if (model.btnId == "btnStep2")
            {
                model.StepNo = 2;
                HttpContext.Session["Step"] = 2;
            }
            if (model.btnId == "btnStep3")
            {
                model.StepNo = 3;
                HttpContext.Session["Step"] = 3;
            }
            if (model.btnId == "btnStep4")
            {
                model.StepNo = 4;
                HttpContext.Session["Step"] = 4;
            }
            if (model.btnId == "btnStep5")
            {
                model.StepNo = 5;
                HttpContext.Session["Step"] = 5;
            }
            ApplicationFormModel objData = ObjApplicationFormDb.UpdateApplicationForm(model, 1);
            DisplayMessage("Success", "Details submitted successfully, do you want to proceed to the next step?", "s");
            SelectList items = DropModel.LoadRelation();
            ViewBag.Relation = items;
            if (objData == null)
            {
                objData = new ApplicationFormModel();
            }
            else if (objData.IAgree)
            {
                String Msg = Convert.ToString(ConfigurationManager.AppSettings["AppNoMsg"]).Replace("[AppNo]", objData.AppNo);
                SMSSender.SMSSend(Msg, model.MobileNo); // Only OTP to verify Mobile Number;
            }
            return View(objData);
        }

        public ActionResult ChangePassword()
        {
            if (SessionManager.RegistrationID == 0)
            {
                return RedirectToAction("UserLogin", "ApplicationForm");
            }
            return View();
        }
        [HttpPost]
        public ActionResult ChangePassword(ChangePass model)
        {
            if (ModelState.IsValid)
            {
                ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
                model.RegistrationID = SessionManager.RegistrationID;
                var data = ObjApplicationFormDb.CheckPassword(model);
                if (data == null)
                {
                    DisplayMessage("Warning", "Old password does not match !", "w");
                }
                else
                {
                    model.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(model.ConfirmPassowrd, "MD5");
                    ObjApplicationFormDb.ChangePassword(model);
                    DisplayMessage("Success", "Password changed successfully !", "s");
                }
            }
            return View();
        }

        public ActionResult Dashboard()
        {
            if (SessionManager.RegistrationID == 0)
            {
                return RedirectToAction("UserLogin", "ApplicationForm");
            }
            return View();
        }

        #region BindBlock

        public JsonResult Bindblock(int districtId)
        {
            ApplicationFormDb objMcon = new ApplicationFormDb();
            BlockModel Model = new BlockModel();
            Model.DistrictID = districtId;
            var List = objMcon.LoadBlockMaster(Model);
            return Json(List, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Check Block

        public JsonResult Checkblock(int blockId)
        {
            ApplicationFormDb objMcon = new ApplicationFormDb();
            BlockModel Model = new BlockModel();
            Model.BlockID = blockId;
            var List = objMcon.CheckBlockMaster(Model);
            return Json(List, JsonRequestBehavior.AllowGet);
        }
        #endregion
        #region BindDistrict

        public JsonResult BindDistrict(int stateId)
        {
            ApplicationFormDb objMcon = new ApplicationFormDb();
            DistrictModel Model = new DistrictModel();
            Model.StateID = stateId;
            var List = objMcon.LoadDistrictMaster(Model);
            return Json(List, JsonRequestBehavior.AllowGet);
        }
        #endregion


        #region FileUpload
        [HttpPost]
        public JsonResult UploadFile()
        {
            string _docname = string.Empty;
            string[] str = null;
            if (System.Web.HttpContext.Current.Request.Files.AllKeys.Any())
            {
                var doc = System.Web.HttpContext.Current.Request.Files["MyImages"];
                string reportName = System.Web.HttpContext.Current.Request.Form["ReportName"].ToString();
                if (doc.ContentLength > 0)
                {
                    _docname = Upload(doc, reportName);
                    str = _docname.Split('_');
                }
            }
            return Json(str, JsonRequestBehavior.AllowGet);
        }

        public string Upload(HttpPostedFile uploadFile, string reportName)
        {
            if (uploadFile.ContentLength > 0)
            {

                DateTime tm = DateTime.Now;
                string _docname = string.Empty;
                string filename = uploadFile.FileName;
                string dirPath = AppDomain.CurrentDomain.BaseDirectory;
                string fileURl = "Content/UploadedDocs/AddressIdProof/";
                _docname = DateTime.Now.ToString("yyyyMMddHHmmssffff");
                string cirfileName = reportName + SessionManager.RegistrationID + _docname;
                string cirextn = Path.GetExtension(filename);

                try
                {
                    String fn = Path.GetFileNameWithoutExtension(filename);
                    String ext = Path.GetExtension(filename);
                    char[] SpecialChars = "!@#$%^&*()+=~`\\|/?><,\"".ToCharArray();
                    int indexOf = fn.IndexOfAny(SpecialChars);
                    String fileName1 = fn;
                    int count = fileName1.Split('.').Length - 1;
                    if (count > 1)
                    {
                        return "Double extension are not allowed in File Name, please rename and try again.";
                    }
                    if (indexOf != -1)
                    {
                        return "Special character are not allowed in File Name, please rename and try again";
                    }

                    string mimetype = uploadFile.ContentType;
                    if (mimetype == "image/jpeg" || mimetype == "image/jpg" || mimetype == "image/jpeg" || mimetype == "application/jpg" || mimetype == "application/x-jpg" || mimetype == "image/pipeg" || mimetype == "image/vnd.swiftview-jpeg" || mimetype == "image/x-xbitmap" || mimetype == "application/octet-stream" || mimetype == "application/pdf")
                    {
                        if ((ext.ToLower() == ".jpg") || (ext.ToLower() == ".jpeg") || ext.ToLower() == ".pdf")
                        {
                            fn = "";
                            string fFullName = filename;
                            int len = fFullName.Length;
                            string ext1 = Path.GetExtension(fFullName);
                            string str = fFullName.Substring(fFullName.LastIndexOf("\\") + 1);
                            len = str.Length;
                            string fileN = str.Substring(0, len - ext1.Length);

                            Regex FilenameRegex = null;
                            FilenameRegex = new Regex("(.*?)\\.(jpeg|jpg|pdf|JPEG|JPG|PDF)$", RegexOptions.IgnoreCase);
                            int index = fileN.IndexOf(".");

                            if (!FilenameRegex.IsMatch(fFullName) || index != -1)
                            {

                                return "Save file without any special character for File name except file extension";
                            }
                            else
                            {
                                string Photoname = Path.GetFileNameWithoutExtension(filename);
                                string fileSize = uploadFile.ContentLength.ToString();
                                String ImageFileNameMBA = filename;
                                Byte[] stu_imageMBA = new Byte[uploadFile.ContentLength];

                                Stream fs = uploadFile.InputStream;
                                fs.Read(stu_imageMBA, 0, Convert.ToInt32(fileSize));

                                fs.Seek(0, SeekOrigin.Begin);
                                StreamReader sr = new StreamReader(fs, true);

                                string firstLine = sr.ReadLine().ToString();

                                if (uploadFile.ContentLength <= 10485760)
                                {
                                    fs.Seek(0, SeekOrigin.Begin);

                                    Stream inputStream = uploadFile.InputStream;

                                    if (System.IO.File.Exists(dirPath + fileURl + cirfileName + cirextn))
                                    {
                                        System.IO.File.Delete(dirPath + fileURl + cirfileName + cirextn);
                                    }

                                    FileStream fs1 = System.IO.File.Create(dirPath + fileURl + cirfileName + cirextn);

                                    uploadFile.InputStream.CopyTo(fs1);
                                    fs1.Close();

                                    return "Success_" + cirfileName + cirextn;
                                }
                                else
                                {
                                    return "Image size can not exceed 12 mb kb in file.";
                                }
                            }
                        }
                        else
                        {
                            return "Please upload .jpg or .jpeg or .pdf file only.";
                        }
                    }
                    else
                    {
                        return "Please upload .jpg or .jpeg or .pdf file only";
                    }
                }
                catch (Exception ex)
                {
                    return "Selected file is not uploaded. Please try again.";
                }
            }

            return "Selected file is not uploaded. Please try again. ";
        }
        #endregion

        #region ForgotPassword

        public ActionResult ForgetPassword(string FT)
        {
            if (!string.IsNullOrEmpty(FT))
            {
                Int16 FormType = Convert.ToInt16(EncriptionDecription.Decrypt(FT));
                SessionManager.FormTypeID = FormType;
                return View();
            }
            else
            {
                return View("TestLinks");
            }
        }

        [HttpPost]
        public ActionResult ForgetPassword(ApplicationFormModel model)
        {
            if (!string.IsNullOrEmpty(model.UserName))
            {
                ApplicationFormDb objDal = new ApplicationFormDb();
                model.OTP = CGeneral.GetRendomNo(6);
                SessionManager.UserName = model.UserName;
                var res = objDal.ForgotPassword(model, 1);
                if (res != null && res.Count > 0)
                {
                    SessionManager.RegistrationID = res[0].RegistrationID;
                    SessionManager.MobileNo = res[0].MobileNo.ToString();
                    String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserForgetMsg"]).Replace("[OTP]", model.OTP);
                    SMSSender.SMSSend(Msg, SessionManager.MobileNo); // Only OTP to verify Mobile Number.                  
                    DisplayMessageWithUrl("Success", "OTP has been sent to your mobile no. XXXXXX" + res[0].MobileNo.Substring(6, 4) + " Please verify.", "s", Url.Action("ForgotPasswordOTPVerification", "ApplicationForm"));
                    //   return RedirectToAction("ForgotPasswordOTPVerification", "ApplicationForm");
                }
                else
                {
                    DisplayMessage("Invalid !", "The User ID you have entered is invalid, please enter correct User ID", "w");
                }
            }
            return View();
        }

        public ActionResult ForgotPasswordOTPVerification()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotPasswordOTPVerification(ApplicationFormModel model)
        {
            if (!string.IsNullOrEmpty(model.OTP))
            {
                if (SessionManager.RegistrationID != 0)
                {
                    ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
                    List<ApplicationFormModel> objData = ObjApplicationFormDb.VerifyUserMobileOTP(SessionManager.RegistrationID, model.OTP);
                    if (objData != null && objData.Count > 0)
                    {
                        if (objData[0].Status == "Success")
                        {
                            model.DisplayPassword = CGeneral.GetRendomPassword(8);
                            model.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(model.DisplayPassword, "MD5");
                            model.RegistrationID = SessionManager.RegistrationID;
                            model.MobileNo = SessionManager.MobileNo;
                            model.UserName = SessionManager.UserName;
                            var res = ObjApplicationFormDb.UpdateUserPassword(model, 1);
                            if (res != null)
                            {
                                String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserResendPassMsg"]).Replace("[ID]", res.UserName).Replace("[Pass]", res.DisplayPassword);
                                SMSSender.SMSSend(Msg, SessionManager.MobileNo); // Only OTP to verify Mobile Number.
                                DisplayMessageWithUrl("Sent", "New password has been sent on your registered mobile no.XXXXXX" + SessionManager.MobileNo.Substring(6, 4) + " , Please login with your new password", "s", Url.Action("UserLogin", "ApplicationForm"));
                                // return RedirectToAction("UserLogin");
                            }
                            else
                            {
                                DisplayMessage("Warning", "Something went wrong please try after some time!", "w");
                            }
                        }
                        else
                        {
                            DisplayMessage("Warning", "OTP did not match,Please enter correct OTP.", "w");
                        }
                    }
                    else
                    {
                        DisplayMessage("Warning", "OTP did not match,Please enter correct OTP.", "w");
                    }
                }
                else
                {
                    return RedirectToAction("UserLogin");
                }
            }
            else
            {
                model.OTP = string.Empty;
                ModelState.AddModelError("OTP", "Please Enter OTP !!");
            }

            return View();
        }

        #endregion

        public ActionResult GetAllUserByMobile(string mobileNo)
        {
            ApplicationFormModel model = new ApplicationFormModel();
            model.MobileNo = mobileNo;
            ApplicationFormDb ObjApplicationFormDb = new ApplicationFormDb();
            model.objUserList = ObjApplicationFormDb.GetallUsernameByMobile(model);
            return PartialView("_RegistrationUserList", model);
        }


        #region For Test
        public ActionResult TestLinks()
        {
            return View();
        }
        #endregion
    }
}
